/*
 * ApexVibe — application logic
 * ------------------------------------------------------------------
 * - All UI is rendered from `assessmentState` (plus a small `ui` object
 *   for purely visual things like which cards are expanded).
 * - All backend work goes through window.ApexApi (mockApi.js).
 * - No framework, no build step.
 */
(function () {
  'use strict';

  const api = window.ApexApi;
  const DEMO = window.ApexDemo;

  /* ================================================================ */
  /* Utilities                                                         */
  /* ================================================================ */

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ESC[c]);
  const isBlank = (v) => v == null || (typeof v === 'string' && v.trim() === '');
  const num = (v) => (typeof v === 'number' && isFinite(v) ? v : (isBlank(v) || isNaN(Number(v)) ? null : Number(v)));
  const pct = (x) => `${Math.round((x || 0) * 100)}%`;
  const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48);

  function getPath(o, path) {
    return path.split('.').reduce((x, k) => (x == null ? undefined : x[k]), o);
  }
  function setPath(o, path, v) {
    const ks = path.split('.');
    let x = o;
    for (let i = 0; i < ks.length - 1; i++) {
      if (x[ks[i]] == null) x[ks[i]] = /^\d+$/.test(ks[i + 1]) ? [] : {};
      x = x[ks[i]];
    }
    x[ks[ks.length - 1]] = v;
  }
  function money(n, cur) {
    const v = num(n);
    if (v == null) return '—';
    try {
      return new Intl.NumberFormat('en-GB', { style: 'currency', currency: (cur || 'GBP').toUpperCase(), minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(v);
    } catch (e) {
      return `${esc(cur || '')} ${v.toLocaleString('en-GB', { maximumFractionDigits: 2 })}`;
    }
  }
  function parseISO(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ''))) return null;
    const [y, m, d] = s.split('-').map(Number);
    const dt = new Date(y, m - 1, d, 12);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
  }
  function fmtDate(s) {
    const d = parseISO(s);
    return d ? d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : (s || '—');
  }
  function fmtTime(ts) {
    return ts ? new Date(ts).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—';
  }
  function fmtBytes(b) {
    if (b < 1024) return `${b} B`;
    if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
    return `${(b / 1048576).toFixed(2)} MB`;
  }
  function termDays(t) { const m = String(t || '').match(/(\d{1,3})/); return m ? Number(m[1]) : null; }
  function normName(s) {
    return String(s || '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9 ]/g, ' ').replace(/\b(ltd|limited|plc|llp|llc|inc|co|company)\b/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function same(a, b) {
    if (isBlank(a) && isBlank(b)) return true;
    if (typeof a === 'number' || typeof b === 'number') return num(a) === num(b);
    return String(a) === String(b);
  }

  /* ================================================================ */
  /* Internal validation (frontend rules, recalculated on every edit)  */
  /* ================================================================ */

  const REQUIRED_FIELDS = [
    ['invoiceNumber', 'Invoice number', true], ['issueDate', 'Issue date', true], ['dueDate', 'Due date', true], ['currency', 'Currency', true],
    ['seller.name', 'Seller name', true], ['seller.registrationNumber', 'Seller registration number', true], ['seller.address', 'Seller address', true],
    ['buyer.name', 'Buyer name', true], ['buyer.registrationNumber', 'Buyer registration number', true], ['buyer.address', 'Buyer address', true],
    ['total', 'Invoice total', true], ['bankDetails.accountName', 'Beneficiary account name', true], ['bankDetails.sortCode', 'Sort code', true], ['bankDetails.accountNumber', 'Account number', true],
    ['paymentTerms', 'Payment terms', false], ['seller.email', 'Seller email', false], ['seller.phone', 'Seller phone', false], ['buyer.email', 'Buyer email', false]
  ];

  const ApexValidation = {
    run(inv) {
      inv = inv || {};
      const cur = inv.currency;
      const checks = [];
      const mk = (id, label, issues, okSummary, meta) => {
        const status = issues.some((i) => i.level === 'fail') ? 'fail' : issues.length ? 'warning' : 'pass';
        const summary = status === 'pass' ? okSummary : `${issues.length} issue${issues.length > 1 ? 's' : ''} found`;
        checks.push(Object.assign({ id, label, status, summary, issues }, meta));
      };

      // 1. Required fields
      const req = [];
      REQUIRED_FIELDS.forEach(([p, label, critical]) => {
        if (isBlank(getPath(inv, p))) req.push({ level: critical ? 'fail' : 'warning', text: `${label} is missing${critical ? '' : ' (recommended)'}.` });
      });
      if (!Array.isArray(inv.items) || !inv.items.length) req.push({ level: 'fail', text: 'Invoice has no line items.' });
      mk('required', 'Required fields', req, `All ${REQUIRED_FIELDS.length} key fields and line items present`, {
        expected: 'Invoice number, dates, currency, both parties, totals and payment details present.',
        why: 'Missing fields prevent verification and are treated as uncertainty, not as safe.',
        toCheck: ['Re-check the source document for the missing values.', 'Request a complete invoice from the seller.'],
        reviewTask: 'Obtain missing invoice information'
      });

      // 2. Arithmetic: sum(line items) − discount + tax = total
      const ar = [];
      const items = inv.items || [];
      let lineSum = 0;
      items.forEach((it, i) => {
        const q = num(it.quantity); const u = num(it.unitPrice); const a = num(it.amount);
        if (a == null) { ar.push({ level: 'fail', text: `Line ${i + 1}: amount missing.` }); return; }
        lineSum += a;
        if (q != null && u != null && Math.abs(q * u - a) > 0.01) ar.push({ level: 'warning', text: `Line ${i + 1}: ${q} × ${money(u, cur)} = ${money(q * u, cur)}, but the line amount is ${money(a, cur)}.` });
      });
      lineSum = Math.round(lineSum * 100) / 100;
      const sub = num(inv.subtotal); const disc = num(inv.discount) || 0; const tax = num(inv.tax) || 0; const tot = num(inv.total);
      const calcTotal = Math.round((lineSum - disc + tax) * 100) / 100;
      if (sub != null && Math.abs(sub - lineSum) > 0.01) ar.push({ level: 'fail', text: `Subtotal ${money(sub, cur)} does not equal the sum of line items ${money(lineSum, cur)}.` });
      if (tot == null) ar.push({ level: 'fail', text: 'Invoice total missing.' });
      else if (Math.abs(calcTotal - tot) > 0.01) ar.push({ level: 'fail', text: `Line items ${money(lineSum, cur)} − discount ${money(disc, cur)} + tax ${money(tax, cur)} = ${money(calcTotal, cur)}, but the invoice total is ${money(tot, cur)} (difference ${money(tot - calcTotal, cur)}).` });
      if (disc < 0 || tax < 0) ar.push({ level: 'warning', text: 'Discount or tax is negative.' });
      mk('arithmetic', 'Arithmetic consistency', ar, `Line items ${money(lineSum, cur)} − ${money(disc, cur)} + ${money(tax, cur)} = ${money(calcTotal, cur)} ✓`, {
        expected: 'sum(line items) − discount + tax = invoice total',
        why: 'Totals that do not add up can indicate an altered or hand-edited invoice, or an extraction error.',
        toCheck: ['Compare totals with the original document.', 'Ask the seller for a corrected invoice.'],
        reviewTask: 'Resolve invoice arithmetic mismatch',
        computed: { lineSum, calcTotal }
      });

      // 3. Dates
      const dt = [];
      const iss = parseISO(inv.issueDate); const due = parseISO(inv.dueDate);
      if (!isBlank(inv.issueDate) && !iss) dt.push({ level: 'fail', text: `Issue date “${inv.issueDate}” is not a valid date.` });
      if (!isBlank(inv.dueDate) && !due) dt.push({ level: 'fail', text: `Due date “${inv.dueDate}” is not a valid date.` });
      if (iss && due) {
        const gap = Math.round((due - iss) / 864e5);
        if (gap < 0) dt.push({ level: 'fail', text: `Due date is ${-gap} day(s) before the issue date.` });
        const t = termDays(inv.paymentTerms);
        if (t != null && gap >= 0 && Math.abs(gap - t) > 1) dt.push({ level: 'warning', text: `Payment terms say ${t} days, but issue→due date is ${gap} days.` });
        if (iss > parseISO(DEMO.today)) dt.push({ level: 'warning', text: 'Issue date is in the future.' });
      }
      mk('dates', 'Date consistency', dt, 'Dates valid, due date after issue date, terms match', {
        expected: 'Valid dates; due date ≥ issue date; issue→due gap matches the payment terms.',
        why: 'Inconsistent dates may indicate an altered invoice or a mis-stated payment term.',
        toCheck: ['Confirm the agreed payment terms with the buyer.'],
        reviewTask: 'Confirm invoice dates and payment terms'
      });

      // 4. Currency
      const cu = [];
      const c0 = String(cur || '').toUpperCase();
      if (c0 && !/^[A-Z]{3}$/.test(c0)) cu.push({ level: 'warning', text: `Currency “${cur}” is not a 3-letter ISO code.` });
      items.forEach((it, i) => { if (it.currency && String(it.currency).toUpperCase() !== c0) cu.push({ level: 'fail', text: `Line ${i + 1} is in ${it.currency}, invoice is in ${cur}.` }); });
      const bc = inv.bankDetails && inv.bankDetails.currency;
      if (bc && c0 && String(bc).toUpperCase() !== c0) cu.push({ level: 'warning', text: `Payment account currency ${bc} differs from invoice currency ${cur}.` });
      mk('currency', 'Currency consistency', cu, `Line items, subtotal, tax, total and payment account all in ${c0 || '—'}`, {
        expected: 'One currency across line items, totals and payment account.',
        why: 'Mixed currencies make totals unreliable and can hide altered payment instructions.',
        toCheck: ['Confirm the invoice and settlement currency with the seller.'],
        reviewTask: 'Confirm invoice currency'
      });

      // 5. Entity consistency
      const en = [];
      const s = inv.seller || {}; const b = inv.buyer || {}; const bank = inv.bankDetails || {};
      if (s.bankAccountName && s.name && normName(s.bankAccountName) !== normName(s.name)) en.push({ level: 'fail', text: `Beneficiary “${s.bankAccountName}” differs from seller legal name “${s.name}”.`, scoredElsewhere: true });
      if (bank.accountName && s.bankAccountName && normName(bank.accountName) !== normName(s.bankAccountName)) en.push({ level: 'warning', text: `Bank account name “${bank.accountName}” differs from the beneficiary named on the invoice “${s.bankAccountName}”.` });
      if (s.registrationNumber && b.registrationNumber && String(s.registrationNumber).trim() === String(b.registrationNumber).trim()) en.push({ level: 'fail', text: 'Seller and buyer share the same registration number.' });
      if (s.name && b.name && normName(s.name) === normName(b.name)) en.push({ level: 'fail', text: 'Seller and buyer have the same name.' });
      if (s.address && b.address && normName(s.address) === normName(b.address)) en.push({ level: 'warning', text: 'Seller and buyer addresses are identical.', scoredElsewhere: true });
      [['Seller', s.registrationNumber], ['Buyer', b.registrationNumber]].forEach(([who, r]) => {
        if (r && !/^[A-Z0-9]{8}$/i.test(String(r).trim())) en.push({ level: 'warning', text: `${who} registration number “${r}” is not in the expected 8-character format.` });
      });
      mk('entity', 'Entity consistency', en, 'Seller, beneficiary, registration and payment details consistent', {
        expected: 'Beneficiary = seller legal name; distinct buyer and seller identities; well-formed registration numbers.',
        why: 'Payment details that do not belong to the seller are one of the strongest indicators of payment-redirection fraud.',
        toCheck: ['Confirm beneficiary details with the seller via a previously verified contact.'],
        reviewTask: 'Independently confirm seller bank details'
      });

      const status = checks.some((c) => c.status === 'fail') ? 'fail' : checks.some((c) => c.status === 'warning') ? 'warning' : 'pass';
      return { status, checks, at: Date.now() };
    }
  };
  window.ApexValidation = ApexValidation;

  /* ================================================================ */
  /* State                                                             */
  /* ================================================================ */

  function createAssessmentState() {
    return {
      assessmentType: 'financing',        // 'financing' | 'counterparty'
      counterpartyRole: 'buyer',          // 'buyer' | 'seller'
      scenarioId: 'A',
      source: null,                       // 'demo' | 'upload' | null
      uploadedFile: null,                 // { file, name, type, size, kind, url, status, progress }
      invoice: null,
      invoiceVersion: 0,
      extraction: { status: 'idle', error: null, original: null, fieldConfidence: {}, notice: '', method: null, key: null, extractedAt: null },
      validation: null,
      processingStatus: { status: 'idle', runId: null, startedAt: null, finishedAt: null, modules: [] },
      riskAssessment: null,
      evidence: [],
      recommendation: null,
      results: null,                      // { invoiceVersion, perspective, completedAt }
      review: { tasks: [], notes: '', evidenceStatus: {}, decision: null, history: [] }
    };
  }

  let assessmentState = createAssessmentState();
  const settings = { devMode: false, failExtraction: false, registryOutage: false, paymentHistoryOutage: false, slowNetwork: false };
  const ui = {
    step: 1,
    expanded: new Set(),
    evidenceFilter: 'all',
    uploadError: null,
    startError: null,
    dialog: null,
    pendingApprove: false,
    reviewMessage: null,
    noteOpen: new Set(),
    lastFocus: null
  };
  let runToken = 0;
  let extractToken = 0;
  let uploadTimer = null;

  const perspectiveOf = (a) => (a.assessmentType === 'financing' ? 'financing' : a.counterpartyRole);
  const PERSPECTIVE_LABEL = { financing: 'Third-party financing', buyer: 'Counterparty · Buyer', seller: 'Counterparty · Seller' };

  /* ================================================================ */
  /* Static config                                                     */
  /* ================================================================ */

  const ST = {
    idle: ['READY', '○', 'muted'], waiting: ['WAITING', '○', 'muted'], running: ['RUNNING', '◌', 'run'],
    pass: ['PASS', '✓', 'ok'], warning: ['WARNING', '!', 'warn'], fail: ['FAIL', '✕', 'bad'],
    unavailable: ['UNABLE TO VERIFY', '?', 'unk'], error: ['ERROR', '✕', 'bad'], cancelled: ['CANCELLED', '–', 'muted']
  };
  function chip(status, label) {
    const s = ST[status] || ST.waiting;
    return `<span class="chip ${s[2]}"><span aria-hidden="true">${s[1]}</span> ${esc(label || s[0])}</span>`;
  }
  const SEV = { critical: ['Critical', 'bad'], high: ['High', 'bad'], medium: ['Medium', 'warn'], low: ['Low', 'info'], none: ['None', 'ok'] };
  function sevChip(sev, prefix) {
    const s = SEV[sev] || SEV.none;
    return `<span class="chip ${s[1]}">${esc(prefix ? `${prefix}: ${s[0]}` : s[0])}</span>`;
  }
  const BAND_TONE = { Low: 'ok', Moderate: 'info', Medium: 'warn', Elevated: 'warn', High: 'bad', Severe: 'bad' };

  const FIELD_GROUPS = [
    { title: 'Invoice details', fields: [
      { path: 'invoiceNumber', label: 'Invoice number' },
      { path: 'issueDate', label: 'Issue date', type: 'date' },
      { path: 'dueDate', label: 'Due date', type: 'date' },
      { path: 'paymentTerms', label: 'Payment terms' },
      { path: 'currency', label: 'Currency' }
    ] },
    { title: 'Seller', fields: [
      { path: 'seller.name', label: 'Legal name' },
      { path: 'seller.registrationNumber', label: 'Registration number' },
      { path: 'seller.address', label: 'Address', wide: true },
      { path: 'seller.email', label: 'Email', type: 'email' },
      { path: 'seller.phone', label: 'Phone' },
      { path: 'seller.bankAccountName', label: 'Beneficiary name on invoice', wide: true }
    ] },
    { title: 'Buyer', fields: [
      { path: 'buyer.name', label: 'Legal name' },
      { path: 'buyer.registrationNumber', label: 'Registration number' },
      { path: 'buyer.address', label: 'Address', wide: true },
      { path: 'buyer.email', label: 'Email', type: 'email', wide: true }
    ] },
    { title: 'Payment / bank details', fields: [
      { path: 'bankDetails.bankName', label: 'Bank' },
      { path: 'bankDetails.accountName', label: 'Account name' },
      { path: 'bankDetails.sortCode', label: 'Sort code' },
      { path: 'bankDetails.accountNumber', label: 'Account number' },
      { path: 'bankDetails.currency', label: 'Account currency' }
    ] },
    { title: 'Totals', fields: [
      { path: 'subtotal', label: 'Subtotal', type: 'number' },
      { path: 'discount', label: 'Discount', type: 'number' },
      { path: 'tax', label: 'Tax', type: 'number' },
      { path: 'total', label: 'Invoice total', type: 'number' }
    ] }
  ];
  const ALL_FIELDS = FIELD_GROUPS.flatMap((g) => g.fields.map((f) => Object.assign({ group: g.title }, f)));

  const PIPELINE = [
    { id: 'validateInvoice', label: 'Invoice validation', desc: 'Required fields, arithmetic, dates, currency and entities', source: 'rules', endpoint: 'POST /invoices/validate', run: (c) => api.validateInvoice(c.invoice) },
    { id: 'verifyBuyer', label: 'Buyer verification', desc: 'Match legal entity and registered address', source: 'registry', endpoint: 'POST /verification/buyer', run: (c) => api.verifyBuyer(c.invoice.buyer) },
    { id: 'verifySeller', label: 'Seller verification', desc: 'Identity, company age and business activity', source: 'registry', endpoint: 'POST /verification/seller', run: (c) => api.verifySeller(c.invoice.seller, c.invoice) },
    { id: 'analyzeRelationship', label: 'Buyer–seller relationship', desc: 'History, shared metadata and supporting documents', source: 'relationship', endpoint: 'POST /relationships/analyze', run: (c) => api.analyzeRelationship(c.invoice.buyer, c.invoice.seller, c.invoice) },
    { id: 'checkBankDetails', label: 'Payment account check', desc: 'Beneficiary name and account-change history', source: 'bank', endpoint: 'POST /payments/bank-details', run: (c) => api.checkBankDetails(c.invoice) },
    { id: 'benchmarkTransaction', label: 'Transaction benchmark', desc: 'Amount, unit price and payment-term anomalies', source: 'market', endpoint: 'POST /transactions/benchmark', run: (c) => api.benchmarkTransaction(c.invoice) },
    { id: 'analyzePaymentHistory', label: 'Payment history analysis', desc: 'Buyer payment behaviour', source: 'payments', endpoint: 'POST /buyers/payment-history', run: (c) => api.getPaymentHistory(c.invoice.buyer) },
    { id: 'checkDuplicateInvoice', label: 'Duplicate & sequence check', desc: 'Ledger search, numbering and creation timing', source: 'ledger', endpoint: 'POST /invoices/duplicates', run: (c) => api.detectDuplicates(c.invoice) },
    { id: 'detectFraudPatterns', label: 'Fraud pattern detection', desc: 'Linked entities and correlated signals', source: 'network', endpoint: 'POST /fraud/assess', run: (c) => api.assessFraud(c.invoice, c.findings) },
    { id: 'calculateRisk', label: 'Risk scoring', desc: 'Backend risk model (mock output)', source: 'model', endpoint: 'POST /risk/score', run: (c) => api.calculateRisk({ perspective: c.perspective, findings: c.findings, patterns: c.patterns }) },
    { id: 'generateRecommendation', label: 'Recommendation', desc: 'Perspective-specific demo policy', source: 'model', endpoint: 'POST /risk/recommendation', run: (c) => api.generateRecommendation({ perspective: c.perspective, invoice: c.invoice, risk: c.risk, findings: c.findings, paymentHistory: c.paymentHistory }) }
  ];

  const SOURCES = [
    { id: 'rules', label: 'Validation rules', desc: 'Client-side consistency checks' },
    { id: 'registry', label: 'Demo company registry', desc: 'Simulated legal-entity reference' },
    { id: 'relationship', label: 'Relationship data', desc: 'Mock history, onboarding & documents' },
    { id: 'bank', label: 'Payee-account history', desc: 'Mock account-change records' },
    { id: 'market', label: 'Market benchmarks', desc: 'Mock price & volume ranges' },
    { id: 'payments', label: 'Payment history', desc: 'Mock buyer payment behaviour' },
    { id: 'ledger', label: 'Invoice & financing ledger', desc: 'Demo duplicate search' },
    { id: 'network', label: 'Fraud-network graph', desc: 'Mock linked-entity data' },
    { id: 'model', label: 'Risk model', desc: 'Mock model output (backend-owned)' }
  ];

  const RISK_TYPES = [
    { id: 'fraud', label: 'Fraud Risk', def: 'The invoice, entities, transaction or payment instructions may be fraudulent.' },
    { id: 'credit', label: 'Credit Risk', def: 'The buyer is legitimate but may not pay, or pay late.' },
    { id: 'transaction', label: 'Transaction Risk', def: 'The invoice may be genuine but commercially abnormal or poorly documented.' },
    { id: 'verification', label: 'Verification Risk', def: 'Information is missing or could not be verified.' }
  ];
  const CATEGORY_LABEL = Object.fromEntries(api.CATEGORIES.map((c) => [c.id, c.label]));

  const PERSPECTIVES = {
    financing: {
      question: 'Should this invoice be financed, and under what conditions?',
      focus: ['Financing eligibility and advance rate', 'Fraud and duplicate-financing indicators', 'Buyer credit quality', 'Verification required before funding']
    },
    buyer: {
      question: 'Is this invoice genuine, and is it safe to pay?',
      focus: ['Verify the seller', 'Verify invoice validity', 'Detect suspicious payment requests', 'Identify fraud indicators']
    },
    seller: {
      question: 'Will this buyer pay, and on what terms should I trade?',
      focus: ['Assess buyer payment risk', 'Analyse historical payment behaviour', 'Recommend payment terms and credit limit']
    }
  };

  /* ================================================================ */
  /* Derived state helpers                                             */
  /* ================================================================ */

  function originalItem(lineId) {
    const o = assessmentState.extraction.original;
    return o && (o.items || []).find((x) => x.lineId === lineId);
  }
  function isEdited(path) {
    const a = assessmentState;
    if (!a.invoice || !a.extraction.original) return false;
    const m = path.match(/^items\.(\d+)\.(\w+)$/);
    if (m) {
      const it = a.invoice.items[Number(m[1])];
      const orig = it && originalItem(it.lineId);
      return !orig || !same(it[m[2]], orig[m[2]]);
    }
    return !same(getPath(a.invoice, path), getPath(a.extraction.original, path));
  }
  function computeEdits() {
    const a = assessmentState;
    if (!a.invoice || !a.extraction.original) return [];
    const edits = [];
    ALL_FIELDS.forEach((f) => {
      if (isEdited(f.path)) edits.push({ label: `${f.group} · ${f.label}`, from: getPath(a.extraction.original, f.path), to: getPath(a.invoice, f.path) });
    });
    a.invoice.items.forEach((it, i) => {
      const orig = originalItem(it.lineId);
      if (!orig) { edits.push({ label: `Line ${i + 1} (added)`, from: '', to: it.description }); return; }
      ['description', 'quantity', 'unitPrice', 'amount', 'currency'].forEach((k) => {
        if (!same(it[k], orig[k])) edits.push({ label: `Line ${i + 1} · ${k}`, from: orig[k], to: it[k] });
      });
    });
    const removed = removedLines();
    removed.forEach((r) => edits.push({ label: 'Line removed', from: r.description, to: '' }));
    return edits;
  }
  function removedLines() {
    const a = assessmentState;
    if (!a.extraction.original) return [];
    const ids = new Set(a.invoice.items.map((x) => x.lineId));
    return a.extraction.original.items.filter((x) => !ids.has(x.lineId));
  }
  function staleReason() {
    const a = assessmentState;
    if (!a.results) return null;
    if (a.results.invoiceVersion !== a.invoiceVersion) return 'Invoice fields changed. Re-run assessment to update risk results.';
    if (a.results.perspective !== perspectiveOf(a)) return `Assessment perspective changed to “${PERSPECTIVE_LABEL[perspectiveOf(a)]}”. Re-run assessment to update the recommendation.`;
    return null;
  }
  function canVisit(n) {
    const a = assessmentState;
    if (settings.devMode || n === 1) return true;
    if (n === 2) return !!a.invoice;
    if (n === 3) return a.processingStatus.status !== 'idle';
    if (n === 4) return !!a.riskAssessment;
    return false;
  }
  function maxReached() {
    const a = assessmentState;
    return a.riskAssessment ? 4 : a.processingStatus.status !== 'idle' ? 3 : a.invoice ? 2 : 1;
  }
  function findingById(id) { return assessmentState.evidence.find((f) => f.id === id); }

  /* ================================================================ */
  /* Navigation, feedback                                              */
  /* ================================================================ */

  function setStep(n, opts) {
    if (!canVisit(n)) return;
    ui.step = n;
    render();
    if (!(opts && opts.noScroll)) window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    const h = $(`#view-${n} .view-title`);
    if (h && !(opts && opts.keepFocus)) h.focus({ preventScroll: true });
  }

  function announce(msg) {
    const r = $('#sr-live');
    r.textContent = '';
    setTimeout(() => { r.textContent = msg; }, 30);
  }
  function toast(msg, tone) {
    const t = document.createElement('div');
    t.className = `toast ${tone || 'info'}`;
    t.setAttribute('role', 'status');
    t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 4200);
  }

  /* ================================================================ */
  /* Upload                                                            */
  /* ================================================================ */

  const MAX_BYTES = 10 * 1024 * 1024;
  const ALLOWED = { pdf: 'pdf', png: 'image', jpg: 'image', jpeg: 'image' };
  const MIME = { 'application/pdf': 'pdf', 'image/png': 'image', 'image/jpeg': 'image', 'image/jpg': 'image' };

  function fileKind(file) {
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (file.type && MIME[file.type]) return MIME[file.type];
    if (!file.type && ALLOWED[ext]) return ALLOWED[ext];
    return null;
  }
  function validateFile(file) {
    if (!file) return 'No file selected.';
    const kind = fileKind(file);
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!kind) return `Unsupported file type (${ext ? '.' + esc(ext) : esc(file.type || 'unknown')}). Upload a PDF, PNG or JPG invoice.`;
    if (file.size === 0) return 'The file is empty. Choose another file.';
    if (file.size > MAX_BYTES) return `File is too large (${fmtBytes(file.size)}). Maximum size is 10 MB.`;
    return null;
  }
  function revokeFile() {
    const f = assessmentState.uploadedFile;
    if (f && f.url) URL.revokeObjectURL(f.url);
    if (uploadTimer) { clearInterval(uploadTimer); uploadTimer = null; }
  }
  function acceptFiles(list) {
    const files = Array.from(list || []);
    if (!files.length) return;
    const file = files[0];
    const err = validateFile(file);
    if (err) {
      ui.uploadError = err;
      render();
      announce(err.replace(/<[^>]+>/g, ''));
      return;
    }
    if (files.length > 1) toast('One invoice per assessment — using the first file.', 'warn');
    revokeFile();
    const a = assessmentState;
    a.uploadedFile = {
      file, name: file.name, type: file.type || `.${file.name.split('.').pop()}`, size: file.size,
      kind: fileKind(file), url: URL.createObjectURL(file), status: 'loading', progress: 0,
      id: `${file.name}:${file.size}:${file.lastModified}`
    };
    a.source = 'upload';
    ui.uploadError = null; ui.startError = null;
    render();
    uploadTimer = setInterval(() => {
      const f = assessmentState.uploadedFile;
      if (!f) { clearInterval(uploadTimer); return; }
      f.progress = Math.min(100, f.progress + 18 + Math.random() * 18);
      if (f.progress >= 100) {
        f.status = 'success';
        clearInterval(uploadTimer); uploadTimer = null;
        announce(`${f.name} attached.`);
      }
      if (ui.step === 1) renderUploadPanel();
    }, 110);
  }
  function removeFile() {
    revokeFile();
    const a = assessmentState;
    a.uploadedFile = null;
    if (a.source === 'upload') a.source = null;
    ui.uploadError = null;
    render();
    announce('File removed.');
  }

  /* ================================================================ */
  /* Extraction                                                        */
  /* ================================================================ */

  function sourceKey(a) {
    if (a.source === 'demo') return `demo:${a.scenarioId}`;
    if (a.source === 'upload' && a.uploadedFile) return `upload:${a.uploadedFile.id}:${a.scenarioId}`;
    return null;
  }
  function clearDownstream() {
    runToken++;
    const a = assessmentState;
    a.invoice = null; a.invoiceVersion = 0;
    a.extraction = { status: 'idle', error: null, original: null, fieldConfidence: {}, notice: '', method: null, key: null, extractedAt: null };
    a.validation = null;
    a.processingStatus = { status: 'idle', runId: null, startedAt: null, finishedAt: null, modules: [] };
    a.riskAssessment = null; a.evidence = []; a.recommendation = null; a.results = null;
    a.review = { tasks: [], notes: '', evidenceStatus: {}, decision: null, history: [] };
    ui.expanded.clear(); ui.noteOpen.clear();
  }

  async function startAssessment() {
    const a = assessmentState;
    ui.startError = null;
    if (!a.source) {
      ui.startError = 'Upload an invoice (PDF, PNG or JPG) or choose “Use Demo Invoice” to continue.';
      render();
      const e = $('#start-error'); if (e) e.focus();
      return;
    }
    if (a.source === 'upload' && (!a.uploadedFile || a.uploadedFile.status !== 'success')) {
      ui.startError = 'Wait for the upload to finish before starting.';
      render();
      return;
    }
    const key = sourceKey(a);
    if (a.invoice && a.extraction.key === key) { setStep(2); return; }
    const hadInvoice = !!a.invoice;
    clearDownstream();
    if (hadInvoice) toast('Previous invoice, results and review notes were cleared.', 'info');
    a.extraction.status = 'loading';
    render();
    announce('Extracting invoice data (simulated).');
    const token = ++extractToken;
    try {
      const res = await api.extractInvoice(a.source === 'upload' ? a.uploadedFile.file : null, { profile: a.scenarioId });
      if (token !== extractToken) return;
      res.invoice.items.forEach((it, i) => { it.lineId = `L${i + 1}`; });
      a.extraction = {
        status: 'success', error: null, original: clone(res.invoice), fieldConfidence: res.fieldConfidence || {},
        notice: res.notice, method: res.method, profile: res.profile, key, extractedAt: res.extractedAt,
        documentName: a.source === 'upload' ? a.uploadedFile.name : DEMO.scenarios.find((s) => s.id === a.scenarioId).fileName
      };
      a.invoice = clone(res.invoice);
      a.invoiceVersion = 1;
      a.validation = ApexValidation.run(a.invoice);
      setStep(2);
      if (a.source === 'upload') toast('Backend extraction is not connected — showing simulated extraction results.', 'warn');
    } catch (err) {
      if (token !== extractToken) return;
      a.extraction.status = 'error';
      a.extraction.error = err.message || 'Extraction failed.';
      render();
      announce(`Extraction failed. ${a.extraction.error}`);
    }
  }

  /* ================================================================ */
  /* Processing pipeline                                               */
  /* ================================================================ */

  async function runAssessment() {
    const a = assessmentState;
    if (!a.invoice) return;
    const token = ++runToken;
    const perspective = perspectiveOf(a);
    const hadDecision = a.review.decision;
    a.processingStatus = {
      status: 'running', runId: `run-${Date.now().toString(36)}`, startedAt: Date.now(), finishedAt: null, perspective,
      modules: PIPELINE.map((m) => ({ id: m.id, status: 'waiting', result: null, ms: null, summary: '' }))
    };
    a.riskAssessment = null; a.evidence = []; a.recommendation = null; a.results = null;
    setStep(3);
    announce('Assessment started.');

    const ctx = { invoice: clone(a.invoice), perspective, findings: [], patterns: [], risk: null, rec: null, paymentHistory: null };
    ctx.invoice.items.forEach((it) => { delete it.lineId; });

    for (let i = 0; i < PIPELINE.length; i++) {
      const m = PIPELINE[i];
      const ms = a.processingStatus.modules[i];
      ms.status = 'running';
      if (ui.step === 3) renderView();
      const t0 = performance.now();
      let res;
      try {
        res = await m.run(ctx);
      } catch (err) {
        res = { status: 'error', summary: err.message || 'Service error', findings: [], confidence: 0, scoreImpact: 0 };
      }
      if (token !== runToken) return;
      ms.ms = Math.round(performance.now() - t0);
      ms.result = res;
      if (res.status === 'error') {
        ms.status = 'error'; ms.summary = res.summary;
      } else if (m.id === 'calculateRisk') {
        ctx.risk = res;
        ms.status = { Low: 'pass', Moderate: 'pass', Elevated: 'warning', High: 'fail', Severe: 'fail' }[res.overall.band];
        ms.summary = `Overall ${res.overall.band} · ${res.overall.score}/100 · fraud ${res.byType.fraud.band.toLowerCase()}, credit ${res.byType.credit.band.toLowerCase()}`;
        ms.confidence = 0.85;
      } else if (m.id === 'generateRecommendation') {
        ctx.rec = res;
        ms.status = res.tone === 'ok' ? 'pass' : res.tone === 'warn' ? 'warning' : 'fail';
        ms.summary = `${res.headline}${res.action ? ' · ' + res.action : ''}`;
        ms.confidence = 0.85;
      } else {
        ms.status = res.status; ms.summary = res.summary; ms.confidence = res.confidence; ms.scoreImpact = res.scoreImpact;
        ctx.findings.push(...res.findings);
        if (res.patterns) ctx.patterns = res.patterns;
        if (m.id === 'analyzePaymentHistory') ctx.paymentHistory = res.data;
        if (m.id === 'validateInvoice' && res.validation) a.validation = res.validation;
      }
      announce(`${m.label}: ${ST[ms.status][0]}`);
      if (ui.step === 3) renderView();
      if ((m.id === 'calculateRisk' || m.id === 'generateRecommendation') && ms.status === 'error') break;
    }
    if (token !== runToken) return;

    const ps = a.processingStatus;
    ps.finishedAt = Date.now();
    if (!ctx.risk || !ctx.rec) {
      ps.status = 'error';
      render();
      announce('Assessment could not be completed.');
      return;
    }
    const partial = ps.modules.some((x) => x.status === 'unavailable' || x.status === 'error');
    ps.status = partial ? 'partial' : 'complete';
    a.riskAssessment = ctx.risk;
    a.evidence = ctx.findings;
    a.recommendation = ctx.rec;
    a.results = { invoiceVersion: a.invoiceVersion, perspective, completedAt: ps.finishedAt, edits: computeEdits().length };
    a.review.tasks = buildTasks(ctx.findings, ctx.risk, perspective, a.review.tasks);
    if (hadDecision) {
      a.review.history.push({ at: Date.now(), action: 'Previous decision cleared by re-run', note: '' });
      a.review.decision = null;
    }
    ui.expanded.clear();
    render();
    announce(`Assessment ${partial ? 'partially ' : ''}complete. Overall risk ${ctx.risk.overall.band}.`);
    setTimeout(() => { if (token === runToken && ui.step === 3) setStep(4); }, 900);
  }

  function cancelRun() {
    runToken++;
    const a = assessmentState;
    a.processingStatus = { status: 'idle', runId: null, startedAt: null, finishedAt: null, modules: [] };
    toast('Assessment cancelled. No results were produced.', 'info');
    setStep(2);
  }

  const BASELINE_TASKS = {
    financing: ['Confirm the invoice has not been assigned to another funder', 'Confirm notice of assignment can be served to the buyer'],
    buyer: ['Match invoice to purchase order and goods receipt'],
    seller: ['Agree payment terms in writing before shipment']
  };
  function buildTasks(findings, risk, perspective, prev) {
    const byId = Object.fromEntries(findings.map((f) => [f.id, f]));
    const tasks = [];
    const seen = new Map();
    risk.drivers.forEach((id) => {
      const f = byId[id];
      if (!f || !f.reviewTask) return;
      if (seen.has(f.reviewTask)) { seen.get(f.reviewTask).signalIds.push(id); return; }
      const t = { id: `task-${slug(f.reviewTask)}`, text: f.reviewTask, signalIds: [id], severity: f.severity, done: false, note: '', custom: false };
      seen.set(f.reviewTask, t); tasks.push(t);
    });
    BASELINE_TASKS[perspective].forEach((text) => {
      if (!seen.has(text)) { const t = { id: `task-${slug(text)}`, text, signalIds: [], severity: 'none', done: false, note: '', custom: false }; seen.set(text, t); tasks.push(t); }
    });
    const old = Object.fromEntries((prev || []).map((t) => [t.id, t]));
    tasks.forEach((t) => { if (old[t.id]) { t.done = old[t.id].done; t.note = old[t.id].note; } });
    (prev || []).filter((t) => t.custom).forEach((t) => tasks.push(t));
    tasks.forEach((t, i) => { t.priority = i + 1; });
    return tasks;
  }

  /* ================================================================ */
  /* Reset                                                             */
  /* ================================================================ */

  function newAssessment() {
    runToken++; extractToken++;
    revokeFile();
    if (ui.dialog) closeDialog(true);
    assessmentState = createAssessmentState();
    ui.expanded.clear(); ui.noteOpen.clear();
    ui.uploadError = null; ui.startError = null; ui.evidenceFilter = 'all'; ui.pendingApprove = false; ui.reviewMessage = null;
    $('#fileInput').value = '';
    ui.step = 1;
    render();
    window.scrollTo({ top: 0 });
    $('#view-1 .view-title').focus({ preventScroll: true });
    toast('New assessment started. Previous data cleared.', 'info');
  }

  /* ================================================================ */
  /* Rendering — shell                                                 */
  /* ================================================================ */

  const VIEWS = [null, renderStep1, renderStep2, renderStep3, renderStep4];

  function render() {
    const ae = document.activeElement;
    const fk = ae && ae.dataset ? ae.dataset.fk : null;
    renderProgress();
    $$('.view').forEach((v) => { v.hidden = Number(v.dataset.view) !== ui.step; });
    renderView();
    if (ui.dialog === 'review') renderDrawer();
    $('#dev-indicator').hidden = !settings.devMode;
    if (fk) {
      const el = document.querySelector(`[data-fk="${CSS.escape(fk)}"]`);
      if (el && el !== document.activeElement) el.focus({ preventScroll: true });
    }
  }
  function renderView() {
    const v = $(`#view-${ui.step}`);
    const ae = document.activeElement;
    const fk = ae && ae.dataset ? ae.dataset.fk : null;
    v.innerHTML = VIEWS[ui.step]();
    if (fk) {
      const el = v.querySelector(`[data-fk="${CSS.escape(fk)}"]`);
      if (el) el.focus({ preventScroll: true });
    }
  }

  function renderProgress() {
    const labels = ['New Assessment', 'Invoice Review', 'Processing', 'Result'];
    const reached = maxReached();
    const stale = !!staleReason();
    $('#progress').innerHTML = labels.map((l, i) => {
      const n = i + 1;
      const active = n === ui.step;
      const done = n < reached || (n === 4 && reached === 4 && !active);
      const ok = canVisit(n);
      const state = active ? 'current step' : done ? 'completed' : ok ? 'available' : 'locked — complete earlier steps first';
      return `<li><button type="button" class="step ${active ? 'active' : ''} ${done && !active ? 'done' : ''} ${n === 4 && stale ? 'stale' : ''}"
        data-action="goto" data-step="${n}" data-fk="step-${n}" ${ok ? '' : 'disabled'} ${active ? 'aria-current="step"' : ''}
        aria-label="Step ${n}: ${l} (${state})">
        <span class="n" aria-hidden="true">${done && !active ? '✓' : n}</span><span class="step-label">${l}</span>
        ${n === 4 && stale ? '<span class="step-flag" aria-hidden="true">Outdated</span>' : ''}
      </button></li>`;
    }).join('');
  }

  /* ================================================================ */
  /* Step 1 — New assessment                                           */
  /* ================================================================ */

  function renderStep1() {
    const a = assessmentState;
    const p = perspectiveOf(a);
    const P = PERSPECTIVES[p];
    const typeCard = (val, title, desc) => `
      <label class="scenario ${a.assessmentType === val ? 'selected' : ''}">
        <input type="radio" name="assessmentType" value="${val}" ${a.assessmentType === val ? 'checked' : ''} data-input="assessmentType">
        <span class="radio-mark" aria-hidden="true"></span>
        <span class="title">${title}</span>
        <span class="desc">${desc}</span>
      </label>`;
    const roleCard = (val, title, desc) => `
      <label class="role ${a.counterpartyRole === val ? 'selected' : ''}">
        <input type="radio" name="counterpartyRole" value="${val}" ${a.counterpartyRole === val ? 'checked' : ''} data-input="counterpartyRole">
        <span class="radio-mark" aria-hidden="true"></span>
        <span><strong>${title}</strong><span class="desc">${desc}</span></span>
      </label>`;
    const scen = DEMO.scenarios.map((s) => {
      const tone = { A: 'ok', B: 'warn', C: 'bad' }[s.id];
      return `<label class="demo-card ${a.scenarioId === s.id ? 'selected' : ''}">
        <input type="radio" name="scenario" value="${s.id}" ${a.scenarioId === s.id ? 'checked' : ''} data-input="scenarioId">
        <span class="demo-top"><strong>${esc(s.label)}</strong><span class="chip ${tone}">${esc(s.riskHint)}</span></span>
        <span class="demo-title">${esc(s.title)}</span>
        <span class="desc">${esc(s.description)}</span>
      </label>`;
    }).join('');

    return `
    <div class="hero">
      <div class="panel pad">
        <div class="eyebrow">New assessment</div>
        <h2 class="view-title" tabindex="-1">Assess a B2B invoice from the right decision perspective.</h2>
        <p class="lead">The same invoice pipeline supports different users. Select who is assessing the invoice, choose a demo scenario, then upload a document or use the demo invoice.</p>

        <fieldset class="group">
          <legend class="section-title">Assessment type</legend>
          <div class="scenario-grid">
            ${typeCard('financing', 'Third-party Financing Assessment', 'For banks, factoring companies, trade-finance providers and financing platforms.')}
            ${typeCard('counterparty', 'Counterparty Assessment', 'For buyers or sellers assessing an invoice, trading counterparty or transaction.')}
          </div>
        </fieldset>

        ${a.assessmentType === 'counterparty' ? `
        <fieldset class="group">
          <legend class="section-title">I am the</legend>
          <div class="role-grid">
            ${roleCard('buyer', 'Buyer', 'Verify the seller and invoice; detect suspicious payment requests.')}
            ${roleCard('seller', 'Seller', 'Assess buyer payment risk; get recommended payment terms.')}
          </div>
        </fieldset>` : ''}

        <div class="question-card">
          <div class="label">Primary question · ${esc(PERSPECTIVE_LABEL[p])}</div>
          <strong>${esc(P.question)}</strong>
          <ul>${P.focus.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
        </div>

        <fieldset class="group">
          <legend class="section-title">Demo scenario</legend>
          <p class="hint">Used by “Use Demo Invoice”, and as the simulated extraction profile for uploaded files.</p>
          <div class="demo-grid">${scen}</div>
        </fieldset>
        ${a.invoice ? `<p class="notice info small" role="note">An invoice is already loaded${a.results ? ' with results' : ''}. Changing the scenario or document and pressing Start will replace it.</p>` : ''}
      </div>

      <div class="panel pad upload-panel" id="upload-panel">${renderUploadPanelInner()}</div>
    </div>`;
  }

  function renderUploadPanel() {
    const el = $('#upload-panel');
    if (!el) return;
    const ae = document.activeElement;
    const fk = ae && ae.dataset ? ae.dataset.fk : null;
    el.innerHTML = renderUploadPanelInner();
    if (fk) { const f = el.querySelector(`[data-fk="${CSS.escape(fk)}"]`); if (f) f.focus({ preventScroll: true }); }
  }

  function renderUploadPanelInner() {
    const a = assessmentState;
    const f = a.uploadedFile;
    const sc = DEMO.scenarios.find((s) => s.id === a.scenarioId);
    const loading = a.extraction.status === 'loading';
    let body;
    if (f) {
      const prev = f.kind === 'image'
        ? `<img class="thumb-img" src="${f.url}" alt="Preview of uploaded invoice image ${esc(f.name)}">`
        : `<div class="pdf-thumb" aria-hidden="true"><span>PDF</span></div>`;
      body = `
        <div class="file-card" data-dropzone>
          <div class="file-head">
            <div class="file-icon ${f.kind}" aria-hidden="true">${f.kind === 'pdf' ? 'PDF' : 'IMG'}</div>
            <div class="file-meta">
              <strong class="file-name">${esc(f.name)}</strong>
              <span>${esc(f.kind === 'pdf' ? 'PDF document' : (f.type || 'Image').replace('image/', '').toUpperCase() + ' image')} · ${fmtBytes(f.size)}</span>
            </div>
          </div>
          ${f.status === 'loading'
            ? `<div class="upload-state" aria-live="polite">Uploading to browser session… ${Math.round(f.progress)}%
                 <div class="bar" role="progressbar" aria-label="Upload progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(f.progress)}"><span style="width:${f.progress}%"></span></div></div>`
            : `<div class="upload-state ok"><span aria-hidden="true">✓</span> File attached · held in this browser only</div>`}
          <div class="preview-box">${prev}</div>
          <div class="file-actions">
            <button type="button" class="btn btn-ghost btn-sm" data-action="browse" data-fk="replace-file" ${loading ? 'disabled' : ''}>Replace</button>
            <button type="button" class="btn btn-ghost btn-sm" data-action="remove-file" data-fk="remove-file" ${loading ? 'disabled' : ''}>Remove</button>
          </div>
          <p class="hint">Backend extraction is not connected. Results will use the simulated <strong>${esc(sc.label)}</strong> extraction profile.</p>
        </div>`;
    } else if (a.source === 'demo') {
      body = `
        <div class="file-card demo-selected">
          <div class="file-head">
            <div class="file-icon pdf" aria-hidden="true">DEMO</div>
            <div class="file-meta">
              <strong class="file-name">${esc(sc.fileName)}</strong>
              <span>${esc(sc.label)} · ${esc(sc.riskHint)} · pre-extracted sample</span>
            </div>
          </div>
          <div class="upload-state ok"><span aria-hidden="true">✓</span> Demo invoice selected</div>
          <div class="file-actions">
            <button type="button" class="btn btn-ghost btn-sm" data-action="browse" data-fk="upload-instead" ${loading ? 'disabled' : ''}>Upload a file instead</button>
            <button type="button" class="btn btn-ghost btn-sm" data-action="clear-demo" data-fk="clear-demo" ${loading ? 'disabled' : ''}>Remove</button>
          </div>
        </div>`;
    } else {
      body = `
        <div class="dropzone" data-dropzone data-action="browse" role="button" tabindex="0" data-fk="dropzone"
             aria-describedby="drop-help" aria-label="Upload invoice: drag and drop a file here, or press Enter to choose a file">
          <div class="upload-icon" aria-hidden="true">↥</div>
          <strong>Drag &amp; drop your invoice here</strong>
          <span id="drop-help">or <span class="link-like">click to choose a file</span> · PDF, PNG or JPG · max 10 MB</span>
        </div>`;
    }
    const extractErr = a.extraction.status === 'error' ? `
      <div class="notice bad" role="alert">
        <strong>Extraction failed.</strong> ${esc(a.extraction.error)}
        <div class="notice-actions"><button type="button" class="btn btn-secondary btn-sm" data-action="start" data-fk="retry-extract">Retry</button>
        ${settings.failExtraction ? '<button type="button" class="btn btn-ghost btn-sm" data-action="open-settings">Demo settings</button>' : ''}</div>
      </div>` : '';
    return `
      <h3>Upload invoice</h3>
      <p class="muted small">PDF, PNG or JPG · max 10 MB · one invoice per assessment</p>
      ${body}
      ${ui.uploadError ? `<div class="notice bad" role="alert" id="upload-error"><strong>Upload failed.</strong> ${ui.uploadError}</div>` : ''}
      <div class="or" aria-hidden="true"><span>or</span></div>
      <button type="button" class="btn btn-secondary btn-block" data-action="use-demo" data-fk="use-demo" ${loading ? 'disabled' : ''} ${a.source === 'demo' ? 'aria-pressed="true"' : ''}>
        ${a.source === 'demo' ? '✓ ' : ''}Use Demo Invoice <span class="muted">(${esc(sc.label)})</span>
      </button>
      ${ui.startError ? `<div class="notice bad" role="alert" id="start-error" tabindex="-1">${esc(ui.startError)}</div>` : ''}
      ${extractErr}
      <button type="button" class="btn btn-primary btn-block btn-lg" data-action="start" data-fk="start" ${loading ? 'disabled aria-busy="true"' : ''}>
        ${loading ? '<span class="spinner" aria-hidden="true"></span> Extracting invoice data (simulated)…' : (a.invoice && a.extraction.key === sourceKey(a) ? 'Continue to Invoice Review' : 'Start Assessment')}
      </button>
      <p class="hint center">Files are not sent anywhere. Extraction and verification are simulated in this demo.</p>`;
  }

  /* ================================================================ */
  /* Step 2 — Invoice review                                           */
  /* ================================================================ */

  function emptyState(title, text, action, label) {
    return `<div class="panel pad empty-state">
      <h2 class="view-title" tabindex="-1">${esc(title)}</h2>
      <p class="lead">${esc(text)}</p>
      ${action ? `<button type="button" class="btn btn-primary" data-action="${action}">${esc(label)}</button>` : ''}
    </div>`;
  }

  function renderPaper(inv) {
    const cur = inv.currency;
    return `<div class="invoice-paper" aria-label="Rendered source invoice">
      <div class="invoice-head">
        <div><h3>INVOICE</h3><small>${esc(inv.invoiceNumber)}</small></div>
        <div class="right"><strong>${esc(inv.seller.name)}</strong><br><small>${esc(inv.seller.address)}</small><br><small>${esc(inv.seller.email)} · ${esc(inv.seller.phone)}</small><br><small>Reg. ${esc(inv.seller.registrationNumber)}</small></div>
      </div>
      <div class="two-col">
        <div><h4>Bill to</h4><p><strong>${esc(inv.buyer.name)}</strong></p><p>${esc(inv.buyer.address)}</p><p>Reg. ${esc(inv.buyer.registrationNumber)}</p></div>
        <div><h4>Invoice details</h4><p>Issue: ${fmtDate(inv.issueDate)}</p><p>Due: ${fmtDate(inv.dueDate)}</p><p>Terms: ${esc(inv.paymentTerms)}</p><p>Currency: ${esc(cur)}</p></div>
      </div>
      <div class="table-scroll"><table class="invoice-table">
        <thead><tr><th>Description</th><th>Qty</th><th>Unit</th><th>Amount</th></tr></thead>
        <tbody>${inv.items.map((it) => `<tr><td>${esc(it.description)}</td><td>${esc(it.quantity)}</td><td>${money(it.unitPrice, cur)}</td><td>${money(it.amount, cur)}</td></tr>`).join('')}</tbody>
      </table></div>
      <div class="invoice-totals">
        <div><span>Subtotal</span><span>${money(inv.subtotal, cur)}</span></div>
        <div><span>Discount</span><span>−${money(inv.discount, cur)}</span></div>
        <div><span>Tax</span><span>${money(inv.tax, cur)}</span></div>
        <div class="grand"><span>Total</span><span>${money(inv.total, cur)}</span></div>
      </div>
      <div class="paper-bank"><h4>Payment details</h4>
        <p>${esc(inv.bankDetails.bankName)} · Account name: <strong>${esc(inv.bankDetails.accountName)}</strong></p>
        <p>Sort code ${esc(inv.bankDetails.sortCode)} · Account ${esc(inv.bankDetails.accountNumber)}</p>
      </div>
    </div>`;
  }

  function fieldHTML(f) {
    const a = assessmentState;
    const val = getPath(a.invoice, f.path);
    const orig = getPath(a.extraction.original, f.path);
    const edited = isEdited(f.path);
    const conf = a.extraction.fieldConfidence[f.path];
    const id = `f-${f.path.replace(/\./g, '-')}`;
    const type = f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : f.type === 'email' ? 'email' : 'text';
    return `<div class="field ${f.wide ? 'wide' : ''} ${edited ? 'is-edited' : ''}" data-edit-wrap="${f.path}">
      <div class="field-top">
        <label for="${id}">${esc(f.label)}</label>
        <span class="edit-flag">Edited</span>
        ${conf != null && conf < 0.85 ? `<span class="conf-flag" title="Extraction confidence ${pct(conf)}">Low confidence · ${pct(conf)}</span>` : ''}
      </div>
      <input id="${id}" data-bind="${f.path}" data-type="${f.type || 'text'}" data-fk="in-${f.path}" type="${type}" value="${esc(val == null ? '' : val)}"
        ${type === 'number' ? 'step="any" inputmode="decimal"' : ''} autocomplete="off" aria-describedby="${id}-orig">
      <div class="field-orig" id="${id}-orig">
        <span class="orig-text">${edited ? `Extracted value: <span class="orig-val">${esc(isBlank(orig) ? '(empty)' : (f.type === 'number' ? money(orig, a.extraction.original.currency) : orig))}</span>` : 'Extracted value'}</span>
        <button type="button" class="link-btn" data-action="revert-field" data-path="${f.path}" data-fk="rv-${f.path}" ${edited ? '' : 'hidden'}>Revert</button>
      </div>
    </div>`;
  }

  function itemsTableHTML() {
    const a = assessmentState;
    const inv = a.invoice;
    const cur = inv.currency;
    const cell = (i, key, type, label) => {
      const path = `items.${i}.${key}`;
      const it = inv.items[i];
      const ed = isEdited(path);
      return `<td class="${ed ? 'is-edited' : ''}" data-edit-wrap="${path}">
        <input data-bind="${path}" data-type="${type}" data-fk="in-${path}" type="${type === 'number' ? 'number' : 'text'}" ${type === 'number' ? 'step="any" inputmode="decimal"' : ''}
          value="${esc(it[key] == null ? '' : it[key])}" aria-label="Line ${i + 1} ${label}${ed ? ' (edited)' : ''}">
      </td>`;
    };
    const removed = removedLines();
    return `
      <div class="table-scroll" role="region" aria-label="Line items" tabindex="0">
        <table class="items-table">
          <thead><tr><th scope="col">Description</th><th scope="col">Qty</th><th scope="col">Unit price</th><th scope="col">Amount</th><th scope="col">Cur.</th><th scope="col"><span class="sr-only">Check</span></th><th scope="col"><span class="sr-only">Remove</span></th></tr></thead>
          <tbody>
          ${inv.items.map((it, i) => {
            const q = num(it.quantity); const u = num(it.unitPrice); const amt = num(it.amount);
            const bad = q != null && u != null && amt != null && Math.abs(q * u - amt) > 0.01;
            const added = !originalItem(it.lineId);
            return `<tr class="${added ? 'added' : ''}">
              ${cell(i, 'description', 'text', 'description')}
              ${cell(i, 'quantity', 'number', 'quantity')}
              ${cell(i, 'unitPrice', 'number', 'unit price')}
              ${cell(i, 'amount', 'number', 'amount')}
              ${cell(i, 'currency', 'text', 'currency')}
              <td class="line-check" data-line-check="${i}">${bad ? `<span class="chip warn" title="Quantity × unit price = ${money(q * u, cur)}">! ${money(q * u, cur)}</span>` : (added ? '<span class="chip info">Added</span>' : '<span class="chip ok" aria-label="Line arithmetic consistent">✓</span>')}</td>
              <td><button type="button" class="icon-btn" data-action="remove-line" data-index="${i}" aria-label="Remove line ${i + 1}">✕</button></td>
            </tr>`;
          }).join('')}
          </tbody>
        </table>
      </div>
      <div class="row-actions">
        <button type="button" class="btn btn-ghost btn-sm" data-action="add-line" data-fk="add-line">+ Add line</button>
        ${removed.length ? `<span class="muted small">${removed.length} extracted line${removed.length > 1 ? 's' : ''} removed</span><button type="button" class="link-btn" data-action="restore-lines" data-fk="restore-lines">Restore</button>` : ''}
      </div>`;
  }

  function validationHTML() {
    const v = assessmentState.validation;
    if (!v) return '';
    const counts = { pass: 0, warning: 0, fail: 0 };
    v.checks.forEach((c) => { counts[c.status]++; });
    return `
      <div class="section-head">
        <h3 class="section-title">Internal validation</h3>
        <span class="muted small" aria-live="polite">${counts.pass} pass · ${counts.warning} warning · ${counts.fail} fail · recalculated live</span>
      </div>
      <ul class="check-list">
      ${v.checks.map((c) => {
        const key = `val-${c.id}`;
        const open = ui.expanded.has(key);
        return `<li class="check ${c.status}">
          <button type="button" class="check-btn" data-action="toggle" data-key="${key}" data-fk="tg-${key}" aria-expanded="${open}" aria-controls="r-${key}">
            <span><strong>${esc(c.label)}</strong><span class="desc">${esc(c.summary)}</span></span>
            <span class="check-right">${chip(c.status)}<span class="caret" aria-hidden="true">▾</span></span>
          </button>
          <div class="check-body" id="r-${key}" ${open ? '' : 'hidden'}>
            ${c.issues.length ? `<ul class="issues">${c.issues.map((i) => `<li class="${i.level}"><span class="sr-only">${i.level === 'fail' ? 'Fail' : 'Warning'}: </span>${esc(i.text)}</li>`).join('')}</ul>` : `<p>${esc(c.summary)}</p>`}
            <dl class="kv"><dt>Rule</dt><dd>${esc(c.expected)}</dd><dt>Why it matters</dt><dd>${esc(c.why)}</dd></dl>
          </div>
        </li>`;
      }).join('')}
      </ul>`;
  }

  function editSummaryHTML() {
    const edits = computeEdits();
    if (!edits.length) return '<span class="muted small">No edits — all values as extracted.</span>';
    return `<span class="chip edited">${edits.length} user edit${edits.length > 1 ? 's' : ''}</span>
      <button type="button" class="link-btn" data-action="revert-all" data-fk="revert-all">Revert all edits</button>`;
  }
  function staleBannerHTML() {
    const r = staleReason();
    if (!r) return '';
    return `<div class="notice warn banner" role="status"><span><strong>Results out of date.</strong> ${esc(r)}</span>
      <button type="button" class="btn btn-primary btn-sm" data-action="run" data-fk="stale-run">Re-run assessment</button></div>`;
  }
  function totalsCalcHTML() {
    const v = assessmentState.validation;
    const inv = assessmentState.invoice;
    if (!v) return '';
    const ar = v.checks.find((c) => c.id === 'arithmetic');
    const comp = ar.computed || {};
    return `<span>Sum of line items <strong>${money(comp.lineSum, inv.currency)}</strong></span>
      <span>Calculated total <strong>${money(comp.calcTotal, inv.currency)}</strong></span>
      <span>Stated total <strong>${money(inv.total, inv.currency)}</strong></span>`;
  }

  function renderStep2() {
    const a = assessmentState;
    if (!a.invoice) return emptyState('No invoice loaded', 'Upload an invoice or choose a demo invoice in step 1 to review extracted data.', 'goto-1', 'Go to New Assessment');
    const ex = a.extraction;
    const f = a.uploadedFile;
    let doc;
    if (a.source === 'upload' && f) {
      doc = f.kind === 'image'
        ? `<figure class="doc-preview"><img src="${f.url}" alt="Uploaded invoice image: ${esc(f.name)}"><figcaption>${esc(f.name)} · ${fmtBytes(f.size)} · client-side preview</figcaption></figure>`
        : `<div class="pdf-panel">
            <div class="pdf-big" aria-hidden="true">PDF</div>
            <strong>${esc(f.name)}</strong>
            <span class="muted small">${fmtBytes(f.size)} · PDF document</span>
            <p class="small">PDF contents are not parsed in the browser. Backend extraction is not connected in this demo, so the fields on the right are <strong>simulated</strong>, not read from this file.</p>
            <a class="btn btn-secondary btn-sm" href="${f.url}" target="_blank" rel="noopener">Open PDF in new tab</a>
          </div>`;
    } else {
      doc = renderPaper(ex.original);
    }
    const confVals = Object.values(ex.fieldConfidence);
    return `
    <div id="stale-slot">${staleBannerHTML()}</div>
    <div class="page2">
      <div class="panel pad source-panel">
        <div class="eyebrow">Source document</div>
        <div class="notice ${ex.method === 'simulated' ? 'warn' : 'info'} small" role="note">${esc(ex.notice)}</div>
        ${doc}
        <dl class="meta-list">
          <div><dt>Extraction</dt><dd>${ex.method === 'simulated' ? 'Simulated (backend not connected)' : 'Demo sample (pre-extracted)'}</dd></div>
          <div><dt>Document</dt><dd>${esc(ex.documentName)}</dd></div>
          <div><dt>Profile</dt><dd>${esc(DEMO.scenarios.find((s) => s.id === ex.profile).label)}</dd></div>
          <div><dt>Low-confidence fields</dt><dd>${confVals.filter((c) => c < 0.85).length}</dd></div>
        </dl>
      </div>

      <div class="panel pad">
        <div class="eyebrow">Structured invoice</div>
        <h2 class="view-title h-md" tabindex="-1">Extracted &amp; normalized data</h2>
        <p class="lead small">Review and correct values before running the assessment. Your edits are flagged and kept separate from the extracted value.</p>
        <div class="legend" aria-hidden="true"><span class="key k-ext">Extracted value</span><span class="key k-edit">User-edited value</span><span class="key k-conf">Low extraction confidence</span></div>
        <div class="edit-summary" id="edit-summary">${editSummaryHTML()}</div>

        ${FIELD_GROUPS.filter((g) => g.title !== 'Totals').map((g) => `
          <fieldset class="field-group"><legend>${esc(g.title)}</legend>
            <div class="field-grid">${g.fields.map(fieldHTML).join('')}</div>
          </fieldset>`).join('')}

        <fieldset class="field-group"><legend>Line items</legend>${itemsTableHTML()}</fieldset>

        <fieldset class="field-group"><legend>Totals</legend>
          <div class="field-grid four">${FIELD_GROUPS.find((g) => g.title === 'Totals').fields.map(fieldHTML).join('')}</div>
          <div class="totals-calc" id="totals-calc" aria-live="polite">${totalsCalcHTML()}</div>
        </fieldset>

        <section class="validation" id="validation-panel" aria-label="Internal validation">${validationHTML()}</section>

        <div class="actions">
          <button type="button" class="btn btn-ghost" data-action="goto" data-step="1">Back</button>
          <button type="button" class="btn btn-primary" data-action="run" data-fk="run">${a.results ? 'Re-run Assessment' : 'Run Assessment'}</button>
        </div>
        ${a.validation && a.validation.status === 'fail' ? '<p class="hint right">Validation failures will be carried into the assessment as risk signals.</p>' : ''}
      </div>
    </div>`;
  }

  let validateTimer = null;
  function onInvoiceInput(el) {
    const a = assessmentState;
    const path = el.dataset.bind;
    let v = el.value;
    if (el.dataset.type === 'number') v = v === '' ? null : Number(v);
    setPath(a.invoice, path, v);
    a.invoiceVersion++;
    const wrap = el.closest('[data-edit-wrap]');
    if (wrap) updateEditFlag(wrap);
    clearTimeout(validateTimer);
    validateTimer = setTimeout(refreshStep2Dynamic, 120);
  }
  function updateEditFlag(wrap) {
    const a = assessmentState;
    const path = wrap.dataset.editWrap;
    const ed = isEdited(path);
    wrap.classList.toggle('is-edited', ed);
    const rv = wrap.querySelector('[data-action="revert-field"]');
    if (rv) rv.hidden = !ed;
    const ot = wrap.querySelector('.orig-text');
    if (ot) {
      const def = ALL_FIELDS.find((f) => f.path === path);
      const orig = getPath(a.extraction.original, path);
      ot.innerHTML = ed ? `Extracted value: <span class="orig-val">${esc(isBlank(orig) ? '(empty)' : (def && def.type === 'number' ? money(orig, a.extraction.original.currency) : orig))}</span>` : 'Extracted value';
    }
  }
  function refreshStep2Dynamic() {
    const a = assessmentState;
    if (!a.invoice) return;
    a.validation = ApexValidation.run(a.invoice);
    const set = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
    set('#validation-panel', validationHTML());
    set('#edit-summary', editSummaryHTML());
    set('#stale-slot', staleBannerHTML());
    set('#totals-calc', totalsCalcHTML());
    $$('[data-line-check]').forEach((td) => {
      const i = Number(td.dataset.lineCheck);
      const it = a.invoice.items[i];
      if (!it) return;
      const q = num(it.quantity); const u = num(it.unitPrice); const amt = num(it.amount);
      const bad = q != null && u != null && amt != null && Math.abs(q * u - amt) > 0.01;
      td.innerHTML = bad ? `<span class="chip warn" title="Quantity × unit price">! ${money(q * u, a.invoice.currency)}</span>` : (!originalItem(it.lineId) ? '<span class="chip info">Added</span>' : '<span class="chip ok" aria-label="Line arithmetic consistent">✓</span>');
    });
    renderProgress();
  }
  function invoiceChanged() {
    const a = assessmentState;
    a.invoiceVersion++;
    a.validation = ApexValidation.run(a.invoice);
    render();
  }

  /* ================================================================ */
  /* Step 3 — Processing                                               */
  /* ================================================================ */

  function renderStep3() {
    const a = assessmentState;
    const ps = a.processingStatus;
    if (ps.status === 'idle') return emptyState('Assessment not started', 'Run the assessment from Invoice Review to see live processing.', a.invoice ? 'goto-2' : 'goto-1', a.invoice ? 'Go to Invoice Review' : 'Go to New Assessment');
    const done = ps.modules.filter((m) => !['waiting', 'running'].includes(m.status)).length;
    const total = ps.modules.length;
    const running = ps.status === 'running';
    const inv = a.invoice;
    const srcStatus = (sid) => {
      const mods = ps.modules.filter((m) => PIPELINE.find((p) => p.id === m.id).source === sid);
      if (mods.some((m) => m.status === 'running')) return ['QUERYING', 'run'];
      if (mods.every((m) => m.status === 'waiting')) return ['READY · MOCK', 'muted'];
      if (mods.some((m) => m.status === 'error')) return ['ERROR', 'bad'];
      if (mods.some((m) => m.result && m.result.findings && m.result.findings.some((f) => f.code === 'unavailable'))) return ['UNAVAILABLE', 'unk'];
      if (mods.some((m) => m.status === 'waiting')) return ['PARTIAL', 'run'];
      return ['RESPONDED', 'ok'];
    };
    const statusLine = {
      running: `Running module ${Math.min(done + 1, total)} of ${total}…`,
      complete: 'All modules complete. Opening results…',
      partial: 'Assessment partially completed — some sources were unavailable. Opening results…',
      error: 'Assessment could not be completed.'
    }[ps.status] || '';
    return `
    <div class="processing-grid">
      <div class="panel pad">
        <div class="eyebrow">Assessment processing</div>
        <h2 class="view-title h-md" tabindex="-1">Building evidence before making a decision.</h2>
        <p class="lead small">Each module calls the frontend API layer. In this demo every response is <strong>simulated</strong> from mock reference data; the same interfaces will later call the backend.</p>
        <div class="run-progress">
          <div class="bar big" role="progressbar" aria-label="Assessment progress" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${done}"><span style="width:${(done / total) * 100}%"></span></div>
          <span class="small ${ps.status === 'error' ? 'bad' : ps.status === 'partial' ? 'warn' : 'muted'}">${esc(statusLine)}</span>
        </div>
        <ol class="process-list">
        ${ps.modules.map((m, i) => {
          const def = PIPELINE[i];
          const st = ST[m.status] || ST.waiting;
          return `<li class="process-item ${m.status}">
            <div class="dot" aria-hidden="true">${m.status === 'waiting' ? i + 1 : st[1]}</div>
            <div class="pi-main">
              <strong>${esc(def.label)}</strong>
              <div class="meta">${esc(m.summary || def.desc)}</div>
              ${m.ms != null ? `<div class="meta tiny">${m.ms} ms${m.confidence ? ` · ${pct(m.confidence)} confidence` : ''} · simulated</div>` : ''}
            </div>
            ${chip(m.status)}
          </li>`;
        }).join('')}
        </ol>
        <div class="actions">
          ${running ? '<button type="button" class="btn btn-ghost" data-action="cancel-run" data-fk="cancel-run">Cancel</button>' : '<button type="button" class="btn btn-ghost" data-action="goto" data-step="2">Back to Invoice Review</button>'}
          ${ps.status === 'error' ? '<button type="button" class="btn btn-primary" data-action="run" data-fk="retry-run">Retry assessment</button>' : ''}
          ${a.riskAssessment ? '<button type="button" class="btn btn-primary" data-action="goto" data-step="4" data-fk="view-results">View results</button>' : ''}
        </div>
      </div>

      <div class="panel pad">
        <div class="eyebrow">Reference data layer</div>
        <h3 class="section-title">Demo data sources</h3>
        ${SOURCES.map((s) => { const [l, c] = srcStatus(s.id); return `<div class="source-card"><div class="top"><strong>${esc(s.label)}</strong><span class="chip ${c}">${l}</span></div><small>${esc(s.desc)}</small></div>`; }).join('')}
        <div class="trace">
          <div class="trace-row"><span>Assessment profile</span><strong>${esc(PERSPECTIVE_LABEL[ps.perspective])}</strong></div>
          <div class="trace-row"><span>Invoice</span><strong>${esc(inv.invoiceNumber)}</strong></div>
          <div class="trace-row"><span>Amount</span><strong>${money(inv.total, inv.currency)}</strong></div>
          <div class="trace-row"><span>Run ID</span><strong>${esc(ps.runId)}</strong></div>
          <div class="trace-row"><span>API mode</span><strong>${esc(api.mode)} (simulated)</strong></div>
          <div class="trace-row"><span>Policy version</span><strong>${esc(DEMO.policyVersion)}</strong></div>
        </div>
      </div>
    </div>`;
  }

  /* ================================================================ */
  /* Step 4 — Results                                                  */
  /* ================================================================ */

  function metric(label, value, sub, tone, extraCls) {
    return `<div class="metric ${tone ? 'tone-' + tone : ''} ${extraCls || ''}">
      <div class="label">${esc(label)}</div>
      <div class="value">${value}</div>
      ${sub ? `<div class="sub">${sub}</div>` : ''}
    </div>`;
  }
  function bandBadge(band, score) {
    return `<span class="band ${BAND_TONE[band] || ''}">${esc(band.toUpperCase())}${score != null ? ` · ${score}/100` : ''}</span>`;
  }

  function renderStep4() {
    const a = assessmentState;
    if (!a.riskAssessment) return emptyState('No results yet', 'Run an assessment to see the recommendation, risk breakdown and evidence.', a.invoice ? 'goto-2' : 'goto-1', a.invoice ? 'Go to Invoice Review' : 'Go to New Assessment');
    const r = a.riskAssessment;
    const rec = a.recommendation;
    const inv = a.invoice;
    const p = a.results.perspective;
    const cur = inv.currency;
    const t = r.byType;

    let cards;
    if (p === 'financing') {
      cards = [
        metric('Recommendation', esc(rec.headline.toUpperCase()), esc(rec.sub), rec.tone, 'hero-metric'),
        metric('Overall Risk', bandBadge(r.overall.band, r.overall.score), 'Mock model output', BAND_TONE[r.overall.band]),
        metric('Fraud Risk', bandBadge(t.fraud.band), `${t.fraud.signals} signal${t.fraud.signals === 1 ? '' : 's'}`, BAND_TONE[t.fraud.band]),
        metric('Credit Risk', bandBadge(t.credit.band), 'Buyer payment risk', BAND_TONE[t.credit.band]),
        metric('Invoice Amount', esc(money(inv.total, cur)), esc(`${cur} · ${inv.invoiceNumber}`)),
        metric('Recommended Financing', rec.advanceRate > 0 ? esc(money(rec.advanceAmount, cur)) : esc(rec.action.toUpperCase()), rec.advanceRate > 0 ? `${Math.round(rec.advanceRate * 100)}% advance · demo policy` : 'No advance until review is complete', rec.tone)
      ];
    } else if (p === 'buyer') {
      cards = [
        metric('Recommendation', esc(rec.headline.toUpperCase()), esc(rec.paymentAction), rec.tone, 'hero-metric'),
        metric('Overall Risk', bandBadge(r.overall.band, r.overall.score), 'Mock model output', BAND_TONE[r.overall.band]),
        metric('Fraud Risk', bandBadge(t.fraud.band), `${t.fraud.signals} signal${t.fraud.signals === 1 ? '' : 's'}`, BAND_TONE[t.fraud.band]),
        metric('Payment-account Risk', bandBadge(rec.paymentAccountRisk), 'Beneficiary & account history', BAND_TONE[rec.paymentAccountRisk]),
        metric('Invoice Amount', esc(money(inv.total, cur)), esc(`${cur} · ${inv.invoiceNumber}`)),
        metric('Seller Identity', esc(rec.sellerStatus), 'Demo verification result', rec.sellerStatus.startsWith('Simulated registry') ? 'ok' : 'warn')
      ];
    } else {
      cards = [
        metric('Recommendation', esc(rec.headline.toUpperCase()), esc(rec.sub), rec.tone, 'hero-metric'),
        metric('Overall Risk', bandBadge(r.overall.band, r.overall.score), 'Mock model output', BAND_TONE[r.overall.band]),
        metric('Fraud Risk', bandBadge(t.fraud.band), `${t.fraud.signals} signal${t.fraud.signals === 1 ? '' : 's'}`, BAND_TONE[t.fraud.band]),
        metric('Credit Risk', bandBadge(t.credit.band), esc(rec.reliability), BAND_TONE[t.credit.band]),
        metric('Invoice Amount', esc(money(inv.total, cur)), esc(`${cur} · ${inv.invoiceNumber}`)),
        metric('Suggested Terms', esc(rec.suggestedTerms), `Credit limit ${esc(rec.creditLimitText)}`, rec.tone)
      ];
    }

    const banners = [];
    const stale = staleReason();
    if (stale) banners.push(staleBannerHTML());
    if (r.partial) banners.push(`<div class="notice unk banner" role="status"><span><strong>Assessment partially completed.</strong> ${r.unavailableCount} check${r.unavailableCount > 1 ? 's' : ''} could not be verified. Unverified information is treated as uncertainty (raising verification risk), not as safe.</span></div>`);
    const d = a.review.decision;
    if (d) banners.push(`<div class="notice ${d.tone} banner" role="status"><span><strong>Reviewer decision: ${esc(d.label)}</strong> · ${fmtTime(d.at)}${d.note ? ` · “${esc(d.note.slice(0, 120))}${d.note.length > 120 ? '…' : ''}”` : ''}<br><span class="small">Recorded in this browser session only — no decision is transmitted.</span></span>
      <button type="button" class="btn btn-ghost btn-sm" data-action="open-review" data-fk="change-decision">Change</button></div>`);

    return `
      <h2 class="view-title sr-only" tabindex="-1">Assessment result</h2>
      ${banners.join('')}
      <div class="result-meta small muted">${esc(PERSPECTIVE_LABEL[p])} · ${esc(inv.seller.name)} → ${esc(inv.buyer.name)} · completed ${fmtTime(a.results.completedAt)} · ${esc(r.modelVersion)}</div>
      <div class="result-head">${cards.join('')}</div>

      <nav class="result-nav" aria-label="Result sections">
        <a href="#sec-reasons">Key reasons</a><a href="#sec-breakdown">Risk breakdown</a><a href="#sec-fraud">Why fraud risk</a>
        <a href="#sec-checks">What to check</a><a href="#sec-evidence">Evidence</a><a href="#sec-trace">Assessment trace</a>
      </nav>

      <div class="result-grid">
        <section class="panel pad" id="sec-reasons" aria-labelledby="h-reasons">${keyReasonsHTML()}</section>
        <section class="panel pad" aria-labelledby="h-persp">${perspectiveHTML()}</section>
      </div>
      <section class="panel pad" id="sec-breakdown" aria-labelledby="h-breakdown">${breakdownHTML()}</section>
      <section class="panel pad" id="sec-fraud" aria-labelledby="h-fraud">${fraudHTML()}</section>
      <section class="panel pad" id="sec-checks" aria-labelledby="h-checks">${checklistHTML('page')}</section>
      <section class="panel pad" id="sec-evidence" aria-labelledby="h-evidence">${evidenceHTML()}</section>
      <section class="panel pad" id="sec-trace" aria-labelledby="h-trace">${traceHTML()}</section>

      <div class="result-actions">
        <button type="button" class="btn btn-ghost" data-action="new-assessment">New Assessment</button>
        <button type="button" class="btn btn-ghost" data-action="goto" data-step="2">Edit invoice</button>
        ${stale ? '<button type="button" class="btn btn-secondary" data-action="run">Re-run assessment</button>' : ''}
        <button type="button" class="btn btn-primary" data-action="open-review" data-fk="open-review">Human Review</button>
      </div>`;
  }

  function issuesRanked() {
    const a = assessmentState;
    return a.riskAssessment.drivers.map(findingById).filter(Boolean);
  }

  function keyReasonsHTML() {
    const issues = issuesRanked();
    const passes = assessmentState.evidence.filter((f) => f.status === 'pass' && f.title).slice(0, 4);
    const top = issues.slice(0, 5);
    return `
      <div class="eyebrow">1 · Key reasons</div>
      <h3 class="h-sm" id="h-reasons">${top.length ? 'What drives this result' : 'Why this looks low risk'}</h3>
      ${top.length ? `<ol class="reasons">${top.map((f) => `<li>
          <div class="reason-top"><strong>${esc(f.title)}</strong>${f.status === 'unavailable' ? chip('unavailable') : sevChip(f.severity, 'Impact')}</div>
          <span class="muted small">${esc(f.observation)}</span></li>`).join('')}</ol>` : '<p class="muted">No material risk signals in the demo checks.</p>'}
      ${passes.length ? `<h4 class="mini-title">Supporting evidence</h4><ul class="positives">${passes.map((f) => `<li><span aria-hidden="true" class="ok">✓</span> ${esc(f.title)}</li>`).join('')}</ul>` : ''}
      <p class="hint">Simulated results. ${issues.length ? 'High-risk indicators are not a finding of fraud; they show where additional verification is recommended.' : 'Low risk in demo data does not guarantee the invoice is genuine.'}</p>`;
  }

  function perspectiveHTML() {
    const a = assessmentState;
    const rec = a.recommendation;
    const r = a.riskAssessment;
    const cur = a.invoice.currency;
    const p = a.results.perspective;
    const fraudSignals = issuesRanked().filter((f) => f.riskType === 'fraud' || f.fraudRelevant).length;
    if (p === 'financing') {
      return `
        <div class="eyebrow">Financing decision</div>
        <h3 class="h-sm" id="h-persp">${esc(rec.headline)}</h3>
        <dl class="kv two">
          <dt>Financing eligibility</dt><dd>${esc(rec.policyTier.action === 'Eligible' && rec.advanceRate > 0 ? 'Eligible' : rec.advanceRate > 0 ? 'Conditional' : 'Not eligible until reviewed')}</dd>
          <dt>Overall risk</dt><dd>${bandBadge(r.overall.band, r.overall.score)}</dd>
          <dt>Suggested advance rate</dt><dd>${rec.advanceRate > 0 ? `${Math.round(rec.advanceRate * 100)}%` : '0% (hold)'}</dd>
          <dt>Suggested advance</dt><dd>${rec.advanceRate > 0 ? money(rec.advanceAmount, cur) : '—'}</dd>
          <dt>Fraud indicators</dt><dd>${fraudSignals}</dd>
          <dt>Verification requirements</dt><dd>${a.review.tasks.length} steps (see “What to check”)</dd>
        </dl>
        <div class="table-scroll"><table class="policy-table">
          <caption class="sr-only">Demo financing policy</caption>
          <thead><tr><th scope="col">Score</th><th scope="col">Band</th><th scope="col">Demo policy</th></tr></thead>
          <tbody>${DEMO.financingPolicy.map((t) => `<tr class="${t.min === rec.policyTier.min ? 'current' : ''}"><td>${t.min}–${t.max}</td><td>${t.band}</td><td>${t.label}${t.min === rec.policyTier.min ? ' <span class="sr-only">(this invoice)</span><span aria-hidden="true"> ◀</span>' : ''}</td></tr>`).join('')}</tbody>
        </table></div>
        <p class="policy-note"><strong>Demo policy</strong> — final credit policy will be provided by the financing institution.</p>`;
    }
    if (p === 'buyer') {
      return `
        <div class="eyebrow">Buyer view</div>
        <h3 class="h-sm" id="h-persp">Recommended payment action</h3>
        <p class="action-callout ${rec.tone}">${esc(rec.paymentAction)}</p>
        <dl class="kv two">
          <dt>Invoice verification status</dt><dd>${esc(rec.invoiceStatus)}</dd>
          <dt>Seller identity status</dt><dd>${esc(rec.sellerStatus)} <span class="muted small">(demo verification result)</span></dd>
          <dt>Payment-account risk</dt><dd>${bandBadge(rec.paymentAccountRisk)}</dd>
          <dt>Overall risk</dt><dd>${bandBadge(r.overall.band, r.overall.score)}</dd>
        </dl>
        <p class="hint">Payment-account status reflects mock account history only. It is not a bank confirmation.</p>`;
    }
    return `
      <div class="eyebrow">Seller view</div>
      <h3 class="h-sm" id="h-persp">Buyer payment risk: ${esc(rec.buyerPaymentRisk)}</h3>
      <dl class="kv two">
        <dt>Buyer payment risk</dt><dd>${bandBadge(rec.buyerPaymentRisk)}</dd>
        <dt>Expected payment reliability</dt><dd>${esc(rec.reliability)} <span class="muted small">(mock payment-history data)</span></dd>
        <dt>Suggested terms</dt><dd>${esc(rec.suggestedTerms)}</dd>
        <dt>Recommended credit limit</dt><dd>${esc(rec.creditLimitText)}</dd>
      </dl>
      <h4 class="mini-title">Documentation required</h4>
      <ul class="doc-list">${rec.documentation.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
      ${rec.fraudNote ? `<p class="notice warn small">${esc(rec.fraudNote)}</p>` : ''}`;
  }
  function breakdownHTML() {
    const r = assessmentState.riskAssessment;
    return `
      <div class="eyebrow">2 · Risk breakdown</div>
      <h3 class="h-sm" id="h-breakdown">Different kinds of risk, scored separately</h3>
      <div class="breakdown">
        <div>
          <ul class="type-list">
            <li class="type-row overall"><div class="type-top"><strong>Overall Risk</strong>${bandBadge(r.overall.band, r.overall.score)}</div>
              <div class="bar" aria-hidden="true"><span class="${BAND_TONE[r.overall.band]}" style="width:${r.overall.score}%"></span></div>
              <span class="muted small">Weighted for the ${esc(PERSPECTIVE_LABEL[r.perspective].toLowerCase())} perspective</span></li>
            ${RISK_TYPES.map((ty) => { const s = r.byType[ty.id]; return `<li class="type-row"><div class="type-top"><strong>${esc(ty.label)}</strong>${bandBadge(s.band, s.score)}</div>
              <div class="bar" aria-hidden="true"><span class="${BAND_TONE[s.band]}" style="width:${s.score}%"></span></div>
              <span class="muted small">${esc(ty.def)}</span></li>`; }).join('')}
          </ul>
        </div>
        <div class="table-scroll">
          <table class="cat-table">
            <caption class="sr-only">Risk by category</caption>
            <thead><tr><th scope="col">Category</th><th scope="col">Status</th><th scope="col">Signals</th><th scope="col">Main driver</th></tr></thead>
            <tbody>${r.categories.map((c) => `<tr>
              <th scope="row">${esc(c.label)}<div class="bar thin" aria-hidden="true"><span class="${c.status === 'fail' ? 'bad' : c.status === 'warning' ? 'warn' : c.status === 'unavailable' ? 'unk' : 'ok'}" style="width:${Math.max(c.score, 3)}%"></span></div></th>
              <td>${chip(c.status, c.status === 'pass' ? 'CLEAR' : c.status === 'warning' ? 'MINOR' : c.status === 'fail' ? 'ELEVATED' : null)}</td>
              <td>${c.issues} / ${c.checks}</td>
              <td class="small">${c.top ? esc(c.top.title) : '<span class="muted">—</span>'}</td>
            </tr>`).join('')}</tbody>
          </table>
        </div>
      </div>`;
  }

  function driverHTML(f, i) {
    return `<li class="driver">
      <div class="driver-head">
        <span class="driver-n" aria-hidden="true">${i + 1}</span>
        <div><h4>${esc(f.title)}</h4>
          <div class="driver-meta">${sevChip(f.severity, 'Impact')}<span class="muted small">${pct(f.confidence)} confidence · +${f.scoreImpact} points · ${esc(CATEGORY_LABEL[f.category])}</span></div>
        </div>
      </div>
      <p>${esc(f.observation)}</p>
      ${f.comparison ? `<div class="comparison"><div class="mini"><label>${esc(f.comparison.leftLabel)}</label><code>${esc(f.comparison.left)}</code></div><div class="mini"><label>${esc(f.comparison.rightLabel)}</label><code>${esc(f.comparison.right)}</code></div></div>` : ''}
      ${f.evidence && f.evidence.length && f.code === 'shared' ? `<ul class="evidence-pills">${f.evidence.map((e) => `<li><strong>${esc(e.label)}</strong> ${esc(e.value)}</li>`).join('')}</ul>` : ''}
      <div class="driver-cols">
        <div><h5>Why this matters</h5><p>${esc(f.whyItMatters)}</p></div>
        <div><h5>What to check</h5><ul>${f.whatToCheck.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>
      </div>
    </li>`;
  }

  function fraudHTML() {
    const r = assessmentState.riskAssessment;
    const fr = r.byType.fraud;
    const show = r.overall.band !== 'Low' || fr.band !== 'Low';
    const drivers = issuesRanked().filter((f) => f.riskType === 'fraud' || f.fraudRelevant).slice(0, 6);
    if (!show) {
      return `<div class="eyebrow">3 · Fraud indicators</div>
        <h3 class="h-sm" id="h-fraud">Fraud risk is low in this demo assessment</h3>
        <p class="muted">No Medium or High fraud indicators were returned by the simulated checks. ${drivers.length ? `${drivers.length} minor item(s) are listed in the evidence panel.` : ''} This does not prove the invoice is genuine; standard verification still applies.</p>`;
    }
    const pat = r.patterns[0];
    let intro;
    if (fr.band === 'High') intro = `Fraud risk is <strong>HIGH (${fr.score}/100)</strong>. High-risk indicators detected. Additional verification is recommended. This is not a determination that any party is fraudulent.`;
    else if (fr.band === 'Medium') intro = `Fraud risk is <strong>MEDIUM (${fr.score}/100)</strong>. Some indicators warrant verification before proceeding.`;
    else intro = `Fraud risk itself is <strong>LOW (${fr.score}/100)</strong>. The ${r.overall.band.toLowerCase()} overall risk comes mainly from ${['credit', 'transaction', 'verification'].filter((k) => r.byType[k].band !== 'Low').join(' and ') || 'transaction'} factors. The items below are the fraud-relevant signals still worth confirming.`;
    return `
      <div class="eyebrow">3 · Fraud drivers</div>
      <h3 class="h-sm" id="h-fraud">Why might fraud risk be high?</h3>
      <p>${intro}</p>
      ${pat ? `<div class="pattern" role="group" aria-labelledby="pat-title">
        <div class="pattern-head"><span class="pattern-icon" aria-hidden="true">⚠</span><div><h4 id="pat-title">Correlated Risk Pattern Detected</h4><span class="muted small">${esc(pat.typology)} · ${pct(pat.confidence)} confidence · +${pat.uplift} points to fraud risk</span></div></div>
        <ul class="pattern-chain">${pat.signals.map((s, i) => `<li>${i ? '<span class="plus" aria-hidden="true">+</span>' : ''}${esc(s)}</li>`).join('')}</ul>
        <p>${esc(pat.explanation)}</p>
        <p class="hint">Correlation output is from the mock model. The production correlation model is backend-owned.</p>
      </div>` : ''}
      ${drivers.length ? `<ol class="drivers">${drivers.map(driverHTML).join('')}</ol>` : '<p class="muted">No fraud-specific indicators were returned.</p>'}`;
  }

  function checklistHTML(where) {
    const rv = assessmentState.review;
    const done = rv.tasks.filter((t) => t.done).length;
    const pfx = where === 'drawer' ? 'dr' : 'pg';
    return `
      ${where === 'page' ? '<div class="eyebrow">4 · What should the reviewer check?</div>' : ''}
      <div class="section-head">
        <h3 class="${where === 'page' ? 'h-sm' : 'section-title'}" id="${where === 'page' ? 'h-checks' : 'dr-checks'}">Recommended verification steps</h3>
        <span class="small muted" aria-live="polite">${done} of ${rv.tasks.length} complete</span>
      </div>
      <div class="bar thin" aria-hidden="true"><span class="ok" style="width:${rv.tasks.length ? (done / rv.tasks.length) * 100 : 0}%"></span></div>
      <ol class="tasks">
      ${rv.tasks.map((t) => {
        const id = `${pfx}-${t.id}`;
        const noteOpen = ui.noteOpen.has(t.id) || t.note;
        return `<li class="task ${t.done ? 'done' : ''}">
          <div class="task-row">
            <span class="prio">Priority ${t.priority}</span>
            <input type="checkbox" id="${id}" data-action="task-toggle" data-task="${t.id}" data-fk="${id}" ${t.done ? 'checked' : ''}>
            <label for="${id}">${esc(t.text)}${t.custom ? ' <span class="chip info">Added by reviewer</span>' : ''}</label>
            <button type="button" class="link-btn" data-action="task-note" data-task="${t.id}" data-fk="${id}-nb" aria-expanded="${noteOpen ? 'true' : 'false'}">${t.note ? 'Edit note' : 'Add note'}</button>
            ${t.custom ? `<button type="button" class="icon-btn" data-action="task-remove" data-task="${t.id}" aria-label="Remove step: ${esc(t.text)}">✕</button>` : ''}
          </div>
          ${t.signalIds.length ? `<div class="task-signals small muted">Related: ${t.signalIds.map((sid) => { const f = findingById(sid); return f ? esc(f.title) : ''; }).filter(Boolean).join(' · ')}</div>` : ''}
          ${noteOpen ? `<label class="sr-only" for="${id}-note">Note for: ${esc(t.text)}</label><input type="text" class="task-note" id="${id}-note" data-task-note="${t.id}" data-fk="${id}-note" value="${esc(t.note)}" placeholder="Note on this step (e.g. who was called, what was confirmed)">` : ''}
        </li>`;
      }).join('')}
      </ol>
      <form class="add-task" data-form="add-task">
        <label class="sr-only" for="${pfx}-new-task">Add a verification step</label>
        <input type="text" id="${pfx}-new-task" name="task" placeholder="Add a verification step…" data-fk="${pfx}-new-task" maxlength="160">
        <button type="submit" class="btn btn-secondary btn-sm">Add step</button>
      </form>
      <div class="notes">
        <label for="${pfx}-notes" class="section-title">Reviewer notes</label>
        <textarea id="${pfx}-notes" data-notes rows="${where === 'page' ? 3 : 4}" data-fk="${pfx}-notes" placeholder="Record what was checked, who was contacted and any conclusions.">${esc(rv.notes)}</textarea>
        <span class="hint">Kept in this browser session only.</span>
      </div>`;
  }

  function evidenceMarkButtons(f, ctx) {
    const s = assessmentState.review.evidenceStatus[f.id];
    return `<div class="mark-btns" role="group" aria-label="Reviewer status for ${esc(f.title)}">
      <button type="button" class="btn btn-xs ${s === 'verified' ? 'on ok' : ''}" data-action="mark" data-id="${f.id}" data-mark="verified" aria-pressed="${s === 'verified'}" data-fk="${ctx}-mv-${f.id}">✓ Verified</button>
      <button type="button" class="btn btn-xs ${s === 'unresolved' ? 'on warn' : ''}" data-action="mark" data-id="${f.id}" data-mark="unresolved" aria-pressed="${s === 'unresolved'}" data-fk="${ctx}-mu-${f.id}">! Unresolved</button>
    </div>`;
  }

  function evidenceHTML() {
    const a = assessmentState;
    const all = issuesRanked().concat(a.evidence.filter((f) => f.status === 'pass'));
    const counts = { all: all.length, issues: all.filter((f) => f.status === 'warning' || f.status === 'fail').length, unavailable: all.filter((f) => f.status === 'unavailable').length, pass: all.filter((f) => f.status === 'pass').length };
    const filt = ui.evidenceFilter;
    const shown = all.filter((f) => filt === 'all' || (filt === 'issues' && (f.status === 'warning' || f.status === 'fail')) || (filt === 'unavailable' && f.status === 'unavailable') || (filt === 'pass' && f.status === 'pass'));
    const fb = (id, label) => `<button type="button" class="filter ${filt === id ? 'on' : ''}" data-action="ev-filter" data-filter="${id}" aria-pressed="${filt === id}" data-fk="evf-${id}">${label} <span class="count">${counts[id]}</span></button>`;
    const es = a.review.evidenceStatus;
    const statusOf = (id) => es[id] === 'verified' ? '<span class="mark ok">✓ Verified by reviewer</span>' : es[id] === 'unresolved' ? '<span class="mark warn">! Unresolved</span>' : '';
    return `
      <div class="eyebrow">5 · Evidence</div>
      <div class="section-head">
        <h3 class="h-sm" id="h-evidence">Evidence for every check</h3>
        <div class="row-actions">
          <button type="button" class="link-btn" data-action="expand-all" data-fk="expand-all">Expand all</button>
          <button type="button" class="link-btn" data-action="collapse-all" data-fk="collapse-all">Collapse all</button>
        </div>
      </div>
      <div class="filters" role="group" aria-label="Filter evidence">${fb('all', 'All')}${fb('issues', 'Issues')}${fb('unavailable', 'Unable to verify')}${fb('pass', 'Passed')}</div>
      <div class="evidence-list">
      ${shown.length ? shown.map((f) => {
        const key = `ev-${f.id}`;
        const open = ui.expanded.has(key);
        return `<article class="evidence-card ${open ? 'open' : ''} st-${f.status}">
          <h4 class="ev-h"><button type="button" class="ev-toggle" data-action="toggle" data-key="${key}" data-fk="tg-${key}" aria-expanded="${open}" aria-controls="r-${key}">
            <span class="ev-title"><strong>${esc(f.title)}</strong><span class="muted small">${esc(CATEGORY_LABEL[f.category])} · ${esc(f.dataSource)}</span></span>
            <span class="ev-right">${statusOf(f.id)}${chip(f.status)}${f.status !== 'pass' ? `<span class="impact">+${f.scoreImpact}</span>` : ''}<span class="caret" aria-hidden="true">▾</span></span>
          </button></h4>
          <div class="evidence-content" id="r-${key}" ${open ? '' : 'hidden'}>
            <dl class="ev-grid">
              <div><dt>Observation</dt><dd>${esc(f.observation)}</dd></div>
              <div><dt>Expected / reference</dt><dd>${esc(f.expected || '—')}</dd></div>
              <div><dt>Difference</dt><dd>${esc(f.difference || '—')}</dd></div>
              <div><dt>Why it matters</dt><dd>${esc(f.whyItMatters || '—')}</dd></div>
              <div><dt>What to check</dt><dd>${f.whatToCheck.length ? `<ul>${f.whatToCheck.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : 'No action needed beyond standard procedure.'}</dd></div>
              <div><dt>Data source</dt><dd>${esc(f.dataSource)} <span class="chip muted">Simulated</span></dd></div>
              <div><dt>Confidence</dt><dd>${pct(f.confidence)} confidence <span class="muted small">— model estimate, not certainty</span></dd></div>
              <div><dt>Risk type</dt><dd>${esc(RISK_TYPES.find((x) => x.id === f.riskType).label)}${f.severity !== 'none' ? ` · ${esc(SEV[f.severity][0])} impact` : ''}</dd></div>
            </dl>
            ${f.comparison ? `<div class="comparison"><div class="mini"><label>${esc(f.comparison.leftLabel)}</label>${esc(f.comparison.left)}</div><div class="mini"><label>${esc(f.comparison.rightLabel)}</label>${esc(f.comparison.right)}</div></div>` : ''}
            ${f.evidence && f.evidence.length ? `<ul class="evidence-pills">${f.evidence.map((e) => `<li><strong>${esc(e.label)}</strong> ${esc(e.value)}</li>`).join('')}</ul>` : ''}
            ${evidenceMarkButtons(f, 'pg')}
          </div>
        </article>`;
      }).join('') : '<p class="muted">No evidence items match this filter.</p>'}
      </div>`;
  }

  function traceHTML() {
    const a = assessmentState;
    const ps = a.processingStatus;
    const key = 'trace';
    const open = ui.expanded.has(key);
    const inv = a.invoice;
    const edits = a.results.edits;
    return `
      <div class="eyebrow">6 · Full assessment trace</div>
      <div class="section-head">
        <h3 class="h-sm" id="h-trace">How this result was produced</h3>
        <button type="button" class="btn btn-ghost btn-sm" data-action="toggle" data-key="${key}" data-fk="tg-trace" aria-expanded="${open}" aria-controls="r-${key}">${open ? 'Hide trace' : 'Show trace'}</button>
      </div>
      <div id="r-${key}" ${open ? '' : 'hidden'}>
        <div class="trace">
          <div class="trace-row"><span>Run ID</span><strong>${esc(ps.runId)}</strong></div>
          <div class="trace-row"><span>Assessment profile</span><strong>${esc(PERSPECTIVE_LABEL[a.results.perspective])}</strong></div>
          <div class="trace-row"><span>Invoice</span><strong>${esc(inv.invoiceNumber)} · ${money(inv.total, inv.currency)}</strong></div>
          <div class="trace-row"><span>Extraction</span><strong>${a.extraction.method === 'simulated' ? 'Simulated' : 'Demo sample'} · ${edits} user edit${edits === 1 ? '' : 's'} applied</strong></div>
          <div class="trace-row"><span>Started / completed</span><strong>${fmtTime(ps.startedAt)} / ${fmtTime(ps.finishedAt)}</strong></div>
          <div class="trace-row"><span>Model / policy</span><strong>${esc(a.riskAssessment.modelVersion)} / ${esc(DEMO.policyVersion)}</strong></div>
          <div class="trace-row"><span>API mode</span><strong>${esc(api.mode)} — all external checks simulated</strong></div>
        </div>
        <div class="table-scroll">
          <table class="trace-table">
            <caption class="sr-only">Module trace</caption>
            <thead><tr><th scope="col">#</th><th scope="col">Module</th><th scope="col">Future endpoint</th><th scope="col">Status</th><th scope="col">Impact</th><th scope="col">Conf.</th><th scope="col">Time</th><th scope="col">Summary</th></tr></thead>
            <tbody>${ps.modules.map((m, i) => `<tr><td>${i + 1}</td><td>${esc(PIPELINE[i].label)}</td><td><code>${esc(PIPELINE[i].endpoint)}</code></td><td>${chip(m.status)}</td><td>${m.scoreImpact != null ? '+' + m.scoreImpact : '—'}</td><td>${m.confidence ? pct(m.confidence) : '—'}</td><td>${m.ms != null ? m.ms + ' ms' : '—'}</td><td class="small">${esc(m.summary)}</td></tr>`).join('')}</tbody>
          </table>
        </div>
      </div>`;
  }

  /* ================================================================ */
  /* Human review drawer & dialogs                                     */
  /* ================================================================ */

  const DECISIONS = {
    approve: { label: 'Approved', tone: 'ok' },
    'more-evidence': { label: 'More evidence requested', tone: 'info' },
    escalate: { label: 'Escalated', tone: 'warn' },
    decline: { label: 'Declined', tone: 'bad' }
  };

  function renderDrawer() {
    const a = assessmentState;
    const body = $('#drawer-body');
    const ae = document.activeElement;
    const fk = ae && ae.dataset ? ae.dataset.fk : null;
    if (!a.riskAssessment) { body.innerHTML = '<p>No assessment to review.</p>'; return; }
    const r = a.riskAssessment;
    const inv = a.invoice;
    const issues = issuesRanked();
    const es = a.review.evidenceStatus;
    const ver = issues.filter((f) => es[f.id] === 'verified').length;
    const unr = issues.filter((f) => es[f.id] === 'unresolved').length;
    body.innerHTML = `
      <div class="drawer-summary">
        <div><span class="muted small">Invoice</span><strong>${esc(inv.invoiceNumber)}</strong></div>
        <div><span class="muted small">Amount</span><strong>${money(inv.total, inv.currency)}</strong></div>
        <div><span class="muted small">Overall risk</span>${bandBadge(r.overall.band, r.overall.score)}</div>
        <div><span class="muted small">Recommendation</span><strong>${esc(a.recommendation.headline)}</strong></div>
      </div>
      <p class="small muted">${esc(inv.seller.name)} → ${esc(inv.buyer.name)} · ${esc(PERSPECTIVE_LABEL[a.results.perspective])}</p>
      ${staleReason() ? `<div class="notice warn small">${esc(staleReason())}</div>` : ''}
      ${a.review.decision ? `<div class="notice ${a.review.decision.tone} small">Current decision: <strong>${esc(a.review.decision.label)}</strong> at ${fmtTime(a.review.decision.at)}</div>` : ''}

      <h3 class="section-title">Major risk signals</h3>
      ${issues.length ? `<ol class="drawer-signals">${issues.slice(0, 5).map((f) => `<li><span>${esc(f.title)}</span>${f.status === 'unavailable' ? chip('unavailable') : sevChip(f.severity)}</li>`).join('')}</ol>` : '<p class="muted small">No material risk signals.</p>'}

      <div class="drawer-section">${checklistHTML('drawer')}</div>

      <div class="drawer-section">
        <div class="section-head"><h3 class="section-title">Evidence status</h3><span class="small muted">${ver} verified · ${unr} unresolved · ${issues.length - ver - unr} not reviewed</span></div>
        ${issues.length ? `<ul class="ev-status-list">${issues.map((f) => `<li><span class="small">${esc(f.title)}</span>${evidenceMarkButtons(f, 'dr')}</li>`).join('')}</ul>` : '<p class="muted small">No issue-level evidence to mark.</p>'}
      </div>

      ${a.review.history.length ? `<div class="drawer-section"><h3 class="section-title">Review history</h3><ul class="history">${a.review.history.slice().reverse().map((h) => `<li><span class="muted small">${fmtTime(h.at)}</span> ${esc(h.action)}${h.note ? ` — “${esc(h.note)}”` : ''}</li>`).join('')}</ul></div>` : ''}
      <div id="review-msg" role="alert" class="${ui.reviewMessage ? 'notice warn small' : ''}">${ui.reviewMessage ? esc(ui.reviewMessage) : ''}</div>
    `;
    $('#approve-btn').textContent = ui.pendingApprove ? 'Confirm approve' : 'Approve';
    if (fk) { const el = body.querySelector(`[data-fk="${CSS.escape(fk)}"]`); if (el) el.focus({ preventScroll: true }); }
  }

  function focusables(root) {
    return $$('a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])', root)
      .filter((el) => !el.hidden && el.offsetParent !== null);
  }
  function openDialog(name) {
    ui.lastFocus = document.activeElement;
    ui.dialog = name;
    const el = name === 'review' ? $('#review-drawer') : $('#settings-dialog');
    if (name === 'review') { ui.pendingApprove = false; ui.reviewMessage = null; renderDrawer(); }
    if (name === 'settings') syncSettingsForm();
    $('#overlay').hidden = false;
    el.hidden = false;
    $('#app').inert = true;
    document.body.classList.add('modal-open');
    requestAnimationFrame(() => { el.classList.add('open'); const f = el.querySelector('[data-autofocus]') || focusables(el)[0]; if (f) f.focus(); });
  }
  function closeDialog(silent) {
    if (!ui.dialog) return;
    const el = ui.dialog === 'review' ? $('#review-drawer') : $('#settings-dialog');
    const was = ui.dialog;
    ui.dialog = null;
    el.classList.remove('open');
    el.hidden = true;
    $('#overlay').hidden = true;
    $('#app').inert = false;
    document.body.classList.remove('modal-open');
    if (was === 'review' && !silent) render();
    if (ui.lastFocus && document.contains(ui.lastFocus)) ui.lastFocus.focus();
    else { const b = $('[data-fk="open-review"]'); if (b) b.focus(); }
  }

  function reviewDecision(kind) {
    const a = assessmentState;
    const rv = a.review;
    const issues = issuesRanked();
    const note = rv.notes.trim();
    if ((kind === 'decline' || kind === 'escalate' || kind === 'more-evidence') && !note) {
      ui.reviewMessage = `Add a reviewer note explaining why you chose “${DECISIONS[kind].label}”.`;
      renderDrawer();
      const n = $('#dr-notes'); if (n) n.focus();
      return;
    }
    if (kind === 'approve' && !ui.pendingApprove) {
      const openP = rv.tasks.filter((t) => !t.done && t.priority <= 3).length;
      const openHigh = issues.filter((f) => (f.severity === 'high' || f.severity === 'critical') && rv.evidenceStatus[f.id] !== 'verified').length;
      const unresolved = issues.filter((f) => rv.evidenceStatus[f.id] === 'unresolved').length;
      if (openP || openHigh || unresolved || staleReason()) {
        const parts = [];
        if (openP) parts.push(`${openP} priority 1–3 step${openP > 1 ? 's are' : ' is'} not complete`);
        if (openHigh) parts.push(`${openHigh} high-impact signal${openHigh > 1 ? 's are' : ' is'} not marked verified`);
        if (unresolved) parts.push(`${unresolved} evidence item${unresolved > 1 ? 's are' : ' is'} marked unresolved`);
        if (staleReason()) parts.push('results are out of date');
        ui.pendingApprove = true;
        ui.reviewMessage = `Before approving: ${parts.join('; ')}. Press “Confirm approve” to approve anyway.`;
        renderDrawer();
        return;
      }
    }
    const d = Object.assign({ kind, at: Date.now(), note }, DECISIONS[kind]);
    rv.decision = d;
    rv.history.push({ at: d.at, action: d.label, note });
    ui.pendingApprove = false; ui.reviewMessage = null;
    closeDialog();
    toast(`Decision recorded: ${d.label} (this browser session only).`, d.tone === 'bad' ? 'bad' : d.tone === 'warn' ? 'warn' : 'ok');
  }

  function syncSettingsForm() {
    Object.keys(settings).forEach((k) => { const el = $(`#set-${k}`); if (el) el.checked = settings[k]; });
  }

  /* ================================================================ */
  /* Events                                                            */
  /* ================================================================ */

  const actions = {
    goto(el) { setStep(Number(el.dataset.step)); },
    'goto-1'() { setStep(1); },
    'goto-2'() { setStep(2); },
    browse() { $('#fileInput').click(); },
    'remove-file': removeFile,
    'use-demo'() {
      const a = assessmentState;
      revokeFile();
      a.uploadedFile = null;
      a.source = 'demo';
      ui.uploadError = null; ui.startError = null;
      renderUploadPanel();
      announce(`${DEMO.scenarios.find((s) => s.id === a.scenarioId).label} invoice selected.`);
    },
    'clear-demo'() { assessmentState.source = null; renderUploadPanel(); announce('Demo invoice removed.'); },
    start: startAssessment,
    run: runAssessment,
    'cancel-run': cancelRun,
    'new-assessment': newAssessment,
    'revert-field'(el) {
      const a = assessmentState;
      const path = el.dataset.path;
      setPath(a.invoice, path, clone(getPath(a.extraction.original, path)));
      const input = $(`[data-bind="${CSS.escape(path)}"]`);
      invoiceChanged();
      const i2 = $(`[data-bind="${CSS.escape(path)}"]`) || input;
      if (i2) i2.focus();
      announce('Field reverted to extracted value.');
    },
    'revert-all'() {
      const a = assessmentState;
      a.invoice = clone(a.extraction.original);
      invoiceChanged();
      announce('All edits reverted.');
      toast('All fields reverted to extracted values.', 'info');
    },
    'add-line'() {
      const a = assessmentState;
      a.invoice.items.push({ lineId: `N${Date.now().toString(36)}`, description: '', quantity: 1, unitPrice: 0, amount: 0, currency: a.invoice.currency });
      invoiceChanged();
      const inputs = $$('[data-bind$=".description"]');
      if (inputs.length) inputs[inputs.length - 1].focus();
    },
    'remove-line'(el) {
      const a = assessmentState;
      a.invoice.items.splice(Number(el.dataset.index), 1);
      invoiceChanged();
      announce('Line removed.');
      const b = $('[data-fk="add-line"]'); if (b) b.focus();
    },
    'restore-lines'() {
      const a = assessmentState;
      const ids = new Set(a.invoice.items.map((x) => x.lineId));
      a.extraction.original.items.forEach((o, i) => { if (!ids.has(o.lineId)) a.invoice.items.splice(Math.min(i, a.invoice.items.length), 0, clone(o)); });
      invoiceChanged();
    },
    toggle(el) {
      const key = el.dataset.key;
      const open = !ui.expanded.has(key);
      if (open) ui.expanded.add(key); else ui.expanded.delete(key);
      $$(`[data-action="toggle"][data-key="${CSS.escape(key)}"]`).forEach((b) => {
        b.setAttribute('aria-expanded', String(open));
        if (key === 'trace') b.textContent = open ? 'Hide trace' : 'Show trace';
      });
      const region = document.getElementById(`r-${key}`);
      if (region) region.hidden = !open;
      const card = el.closest('.evidence-card');
      if (card) card.classList.toggle('open', open);
    },
    'expand-all'() {
      $$('.evidence-card [data-action="toggle"]').forEach((b) => { ui.expanded.add(b.dataset.key); });
      renderView();
    },
    'collapse-all'() {
      $$('.evidence-card [data-action="toggle"]').forEach((b) => { ui.expanded.delete(b.dataset.key); });
      renderView();
    },
    'ev-filter'(el) { ui.evidenceFilter = el.dataset.filter; renderView(); },
    mark(el) {
      const es = assessmentState.review.evidenceStatus;
      const id = el.dataset.id; const m = el.dataset.mark;
      if (es[id] === m) delete es[id]; else es[id] = m;
      ui.pendingApprove = false;
      if (ui.dialog === 'review') renderDrawer(); else renderView();
      const f = findingById(id);
      announce(`${f ? f.title : 'Evidence'}: ${es[id] ? (es[id] === 'verified' ? 'marked verified' : 'marked unresolved') : 'status cleared'}.`);
    },
    'task-note'(el) {
      const id = el.dataset.task;
      if (ui.noteOpen.has(id)) ui.noteOpen.delete(id); else ui.noteOpen.add(id);
      if (ui.dialog === 'review') renderDrawer(); else renderView();
      const input = (ui.dialog === 'review' ? $('#drawer-body') : $(`#view-${ui.step}`)).querySelector(`[data-task-note="${CSS.escape(id)}"]`);
      if (input) input.focus();
    },
    'task-remove'(el) {
      const rv = assessmentState.review;
      rv.tasks = rv.tasks.filter((t) => t.id !== el.dataset.task);
      rv.tasks.forEach((t, i) => { t.priority = i + 1; });
      if (ui.dialog === 'review') renderDrawer(); else renderView();
    },
    'open-review'() { if (assessmentState.riskAssessment) openDialog('review'); },
    'close-dialog'() { closeDialog(); },
    'review-decision'(el) { reviewDecision(el.dataset.decision); },
    'open-settings'() { openDialog('settings'); }
  };

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-action]');
    if (!el || el.disabled) return;
    if (el.type === 'checkbox') return; // handled on change
    const fn = actions[el.dataset.action];
    if (!fn) return;
    if (el.tagName === 'A') e.preventDefault();
    fn(el, e);
  });

  document.addEventListener('keydown', (e) => {
    // Keyboard activation for role="button" elements (the dropzone)
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role="button"][data-action]')) {
      e.preventDefault();
      actions[e.target.dataset.action](e.target, e);
      return;
    }
    if (!ui.dialog) return;
    const el = ui.dialog === 'review' ? $('#review-drawer') : $('#settings-dialog');
    if (e.key === 'Escape') { e.preventDefault(); closeDialog(); return; }
    if (e.key === 'Tab') {
      const f = focusables(el);
      if (!f.length) return;
      const first = f[0]; const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  document.addEventListener('change', (e) => {
    const el = e.target;
    const a = assessmentState;
    if (el.id === 'fileInput') { acceptFiles(el.files); el.value = ''; return; }
    if (el.dataset.input === 'assessmentType' || el.dataset.input === 'counterpartyRole') {
      a[el.dataset.input] = el.value;
      renderView(); renderProgress();
      const sel = $(`input[name="${el.name}"]:checked`); if (sel) sel.focus();
      if (staleReason()) toast('Perspective changed — re-run the assessment to update results.', 'warn');
      return;
    }
    if (el.dataset.input === 'scenarioId') {
      a.scenarioId = el.value;
      ui.startError = null;
      renderView();
      const sel = $('input[name="scenario"]:checked'); if (sel) sel.focus();
      return;
    }
    if (el.dataset.action === 'task-toggle') {
      const t = a.review.tasks.find((x) => x.id === el.dataset.task);
      if (t) t.done = el.checked;
      ui.pendingApprove = false;
      if (ui.dialog === 'review') renderDrawer(); else renderView();
      announce(`${t.text}: ${t.done ? 'done' : 'not done'}.`);
      return;
    }
    if (el.dataset.setting) {
      settings[el.dataset.setting] = el.checked;
      api.configure(settings);
      renderProgress();
      $('#dev-indicator').hidden = !settings.devMode;
      if (ui.step === 1) renderUploadPanel();
    }
  });

  document.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.bind) { onInvoiceInput(el); return; }
    if (el.matches('[data-notes]')) { assessmentState.review.notes = el.value; ui.reviewMessage = null; return; }
    if (el.dataset.taskNote) {
      const t = assessmentState.review.tasks.find((x) => x.id === el.dataset.taskNote);
      if (t) t.note = el.value;
    }
  });

  document.addEventListener('submit', (e) => {
    const form = e.target;
    if (form.dataset.form !== 'add-task') return;
    e.preventDefault();
    const input = form.querySelector('input');
    const text = input.value.trim();
    if (!text) { input.focus(); return; }
    const rv = assessmentState.review;
    rv.tasks.push({ id: `task-custom-${Date.now().toString(36)}`, text, signalIds: [], severity: 'none', done: false, note: '', custom: true, priority: rv.tasks.length + 1 });
    if (ui.dialog === 'review') renderDrawer(); else renderView();
    const again = document.getElementById(input.id); if (again) again.focus();
    announce(`Verification step added: ${text}`);
  });

  // Drag & drop
  let dragDepth = 0;
  document.addEventListener('dragenter', (e) => {
    const z = e.target.closest && e.target.closest('[data-dropzone]');
    if (!z) return;
    e.preventDefault(); dragDepth++; z.classList.add('dragover');
  });
  document.addEventListener('dragover', (e) => {
    e.preventDefault();
    const z = e.target.closest && e.target.closest('[data-dropzone]');
    if (e.dataTransfer) e.dataTransfer.dropEffect = z ? 'copy' : 'none';
  });
  document.addEventListener('dragleave', (e) => {
    const z = e.target.closest && e.target.closest('[data-dropzone]');
    if (!z) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) z.classList.remove('dragover');
  });
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDepth = 0;
    $$('.dragover').forEach((z) => z.classList.remove('dragover'));
    const z = e.target.closest && e.target.closest('[data-dropzone]');
    if (!z || ui.step !== 1) return;
    if (assessmentState.extraction.status === 'loading') return;
    acceptFiles(e.dataTransfer && e.dataTransfer.files);
  });

  // In-page section links should move focus too
  document.addEventListener('click', (e) => {
    const a = e.target.closest('.result-nav a');
    if (!a) return;
    e.preventDefault();
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
    }
  });

  /* ================================================================ */
  /* Init                                                              */
  /* ================================================================ */

  api.configure(settings);
  render();

  // Read-only handle for debugging in the console
  window.ApexApp = { get state() { return assessmentState; }, get ui() { return ui; }, settings };
})();
