/*
 * ApexVibe demo data
 * ------------------------------------------------------------------
 * Everything in this file is FICTIONAL demo data. Company names,
 * registration numbers, phone numbers and bank details are invented.
 *
 * Two kinds of data live here:
 *   1. scenarios  – the demo invoices a user can load (what the
 *                   backend extraction service would return).
 *   2. reference  – the mock "reference data layer" the mock API
 *                   (mockApi.js) consults. In production these lookups
 *                   happen server-side; the frontend never sees them.
 *
 * Dates are generated relative to "today" so the scenarios stay
 * realistic whenever the demo is opened.
 */
(function () {
  'use strict';

  const DAY = 864e5;
  const now = new Date();
  now.setHours(12, 0, 0, 0);

  /** ISO date (YYYY-MM-DD, local time) offset from today by n days. */
  function d(n) {
    const x = new Date(now.getTime() + n * DAY);
    const mm = String(x.getMonth() + 1).padStart(2, '0');
    const dd = String(x.getDate()).padStart(2, '0');
    return `${x.getFullYear()}-${mm}-${dd}`;
  }

  /* ---------------------------------------------------------------- */
  /* Demo invoices                                                     */
  /* ---------------------------------------------------------------- */

  const scenarios = [
    {
      id: 'A',
      label: 'Demo A',
      riskHint: 'Low risk',
      title: 'Established design supplier',
      description: 'Verified-looking counterparties, a 2½-year trading relationship, normal pricing and good payment history.',
      fileName: 'demo_invoice_INV-2026-014.pdf',
      fieldConfidence: {},
      invoice: {
        invoiceNumber: 'INV-2026-014',
        issueDate: d(-6),
        dueDate: d(8),
        currency: 'GBP',
        seller: {
          name: 'Adaeze Okonkwo Studio Ltd',
          registrationNumber: '11823456',
          address: '18 Shoreditch High Street, London E1 6PG',
          email: 'accounts@okonkwostudio.co.uk',
          phone: '+44 20 7946 0321',
          bankAccountName: 'Adaeze Okonkwo Studio Ltd'
        },
        buyer: {
          name: 'Harbour & Vine Ltd',
          registrationNumber: '09876543',
          address: '22 Rivington Street, London EC2A 3DU',
          email: 'ap@harbourvine.co.uk'
        },
        items: [
          { description: 'Brand identity package', quantity: 1, unitPrice: 2400, amount: 2400, currency: 'GBP' },
          { description: 'Website design (per page)', quantity: 3, unitPrice: 450, amount: 1350, currency: 'GBP' },
          { description: 'Post-launch support (hours)', quantity: 6, unitPrice: 80, amount: 480, currency: 'GBP' }
        ],
        subtotal: 4230,
        discount: 200,
        tax: 0,
        total: 4030,
        paymentTerms: 'Net 14',
        bankDetails: {
          bankName: 'Northern Counties Bank (demo)',
          accountName: 'Adaeze Okonkwo Studio Ltd',
          sortCode: '20-45-77',
          accountNumber: '43819027',
          currency: 'GBP'
        }
      }
    },
    {
      id: 'B',
      label: 'Demo B',
      riskHint: 'Medium risk',
      title: 'New buyer, unusually large order',
      description: 'First invoice to a new buyer, amount well above the seller’s normal range, limited buyer history and a slight pricing anomaly.',
      fileName: 'demo_invoice_NPC-24561.pdf',
      fieldConfidence: { 'items.2.unitPrice': 0.82 },
      invoice: {
        invoiceNumber: 'NPC-24561',
        issueDate: d(-5),
        dueDate: d(40),
        currency: 'GBP',
        seller: {
          name: 'Northfield Precision Components Ltd',
          registrationNumber: '10457721',
          address: 'Unit 7, Riverside Industrial Estate, Sheffield S9 2RT',
          email: 'accounts@northfieldprecision.co.uk',
          phone: '+44 114 496 0117',
          bankAccountName: 'Northfield Precision Components Ltd'
        },
        buyer: {
          name: 'Calder Logistics Group Ltd',
          registrationNumber: '08812290',
          address: 'Calder House, 3 Wharf Street, Leeds LS2 7EQ',
          email: 'payables@calderlogistics.co.uk'
        },
        items: [
          { description: 'Machined aluminium brackets AB-220', quantity: 1200, unitPrice: 17.5, amount: 21000, currency: 'GBP' },
          { description: 'Steel mounting plates SP-80', quantity: 400, unitPrice: 14.25, amount: 5700, currency: 'GBP' },
          { description: 'Custom tooling setup', quantity: 1, unitPrice: 3500, amount: 3500, currency: 'GBP' }
        ],
        subtotal: 30200,
        discount: 0,
        tax: 6040,
        total: 36240,
        paymentTerms: 'Net 45',
        bankDetails: {
          bankName: 'Pennine Commercial Bank (demo)',
          accountName: 'Northfield Precision Components Ltd',
          sortCode: '40-11-62',
          accountNumber: '71553904',
          currency: 'GBP'
        }
      }
    },
    {
      id: 'C',
      label: 'Demo C',
      riskHint: 'High fraud risk',
      title: 'New seller, changed bank account',
      description: 'Several correlated indicators: 19-day-old seller, oversized first invoice, recently changed payee account, shared metadata and a near-duplicate.',
      fileName: 'demo_invoice_INV-000187.pdf',
      fieldConfidence: { 'seller.bankAccountName': 0.74, 'paymentTerms': 0.81 },
      invoice: {
        invoiceNumber: 'INV-000187',
        issueDate: d(-1),
        dueDate: d(6),
        currency: 'GBP',
        seller: {
          name: 'Brightline Trade Supplies Ltd',
          registrationNumber: '16034418',
          address: '88 Commercial Road, London E1 1RD',
          email: 'brightline.accounts@mailbox-demo.net',
          phone: '+44 118 496 0731',
          bankAccountName: 'BL Trading Services'
        },
        buyer: {
          name: 'Meridian Retail Holdings Ltd',
          registrationNumber: '07345120',
          address: 'Meridian House, 40 Kingsway Park, Reading RG1 8ZZ',
          email: 'ap@meridianretail.co.uk'
        },
        items: [
          { description: 'Wireless earbuds model X2 (consumer electronics)', quantity: 1500, unitPrice: 39.6, amount: 59400, currency: 'GBP' },
          { description: 'Express logistics & handling', quantity: 1, unitPrice: 9000, amount: 9000, currency: 'GBP' }
        ],
        subtotal: 68400,
        discount: 0,
        tax: 13680,
        total: 82080,
        paymentTerms: 'Net 5',
        bankDetails: {
          bankName: 'Metro Digital Bank (demo)',
          accountName: 'BL Trading Services',
          sortCode: '04-00-75',
          accountNumber: '19374628',
          currency: 'GBP'
        }
      }
    }
  ];

  /* ---------------------------------------------------------------- */
  /* Mock reference data layer (stands in for backend data sources)   */
  /* ---------------------------------------------------------------- */

  const reference = {
    /** Demo company registry, keyed by registration number. */
    companies: {
      '11823456': { name: 'Adaeze Okonkwo Studio Ltd', status: 'Active', incorporated: d(-2210), address: '18 Shoreditch High Street, London E1 6PG', activity: 'Specialised design activities (SIC 74100)', sectors: ['design'], directors: ['Adaeze Okonkwo'], phone: '+44 20 7946 0321', accountsFiled: true, annualTurnover: 182000 },
      '09876543': { name: 'Harbour & Vine Ltd', status: 'Active', incorporated: d(-4050), address: '22 Rivington Street, London EC2A 3DU', activity: 'Licensed restaurants and bars (SIC 56101)', sectors: ['hospitality'], directors: ['Tomás Reyes', 'Priya Natarajan'], phone: '+44 20 7946 0874', accountsFiled: true, annualTurnover: 3400000 },
      '10457721': { name: 'Northfield Precision Components Ltd', status: 'Active', incorporated: d(-3300), address: 'Unit 7, Riverside Industrial Estate, Sheffield S9 2RT', activity: 'Manufacture of other fabricated metal products (SIC 25990)', sectors: ['metal-fabrication'], directors: ['Gareth Lowe'], phone: '+44 114 496 0117', accountsFiled: true, annualTurnover: 1420000 },
      '08812290': { name: 'Calder Logistics Group Ltd', status: 'Active', incorporated: d(-1460), address: 'Calder House, 3 Wharf Street, Leeds LS2 7EQ', activity: 'Freight transport by road (SIC 49410)', sectors: ['logistics'], directors: ['Imran Siddiqui', 'Helen Marsh'], phone: '+44 113 496 0552', accountsFiled: true, annualTurnover: 6100000 },
      '16034418': { name: 'Brightline Trade Supplies Ltd', status: 'Active', incorporated: d(-19), address: 'Suite 4B, 12 Marsh Lane, Croydon CR0 1PQ', activity: 'Management consultancy activities (SIC 70229)', sectors: ['consultancy'], directors: ['Jonas Halvorsen'], phone: '+44 20 7946 0990', accountsFiled: false, annualTurnover: null },
      '07345120': { name: 'Meridian Retail Holdings Ltd', status: 'Active', incorporated: d(-5120), address: 'Meridian House, 40 Kingsway Park, Reading RG1 8ZZ', activity: 'Retail sale of electrical goods (SIC 47430)', sectors: ['retail'], directors: ['Claire Abbott', 'Jonas Halvorsen'], phone: '+44 118 496 0731', accountsFiled: true, annualTurnover: 48500000 },
      '14988102': { name: 'Quayside Component Traders Ltd', status: 'Active', incorporated: d(-41), address: '3 Dock Road, Tilbury RM18 7AA', activity: 'Wholesale of other machinery (SIC 46690)', sectors: ['wholesale'], directors: ['M. Reiter'], phone: '+44 20 7946 0412', accountsFiled: false, annualTurnover: null },
      '15520317': { name: 'Northgate Supply Partners Ltd', status: 'Active', incorporated: d(-63), address: '71 Station Parade, Harrow HA1 2TT', activity: 'Non-specialised wholesale trade (SIC 46900)', sectors: ['wholesale'], directors: ['S. Okafor'], phone: '+44 20 7946 0655', accountsFiled: false, annualTurnover: null }
    },

    /** Mock onboarding metadata (device fingerprints etc.), keyed by registration number. */
    onboarding: {
      '11823456': { deviceId: 'dev-21c0e4' },
      '09876543': { deviceId: 'dev-9ab713' },
      '10457721': { deviceId: 'dev-55d2f0' },
      '08812290': { deviceId: 'dev-c4180b' },
      '16034418': { deviceId: 'dev-7f3a91' },
      '07345120': { deviceId: 'dev-7f3a91' }
    },

    /** Seller invoicing profile derived from historical invoices. */
    sellerProfiles: {
      '11823456': { invoicesLast12m: 26, typicalRange: [2800, 5200], recentNumbers: ['INV-2026-012', 'INV-2026-013'] },
      '10457721': { invoicesLast12m: 214, typicalRange: [8000, 15000], recentNumbers: ['NPC-24556', 'NPC-24558'] },
      '16034418': { invoicesLast12m: 2, typicalRange: [1150, 2300], recentNumbers: ['BTS-0003', 'BTS-0004'] }
    },

    /** Buyer–seller relationship store, keyed "sellerReg|buyerReg". */
    relationships: {
      '11823456|09876543': { since: d(-912), invoiceCount: 14, range: [2800, 5200], disputes: 0, buyerShareOfSellerRevenue: 0.18, documents: { purchaseOrder: true, deliveryEvidence: true } },
      '10457721|08812290': { since: d(-28), invoiceCount: 0, purchaseOrders: 1, range: null, disputes: 0, buyerShareOfSellerRevenue: null, documents: { purchaseOrder: true, deliveryEvidence: false } }
    },

    /** Payee account records, keyed by sortcode+account digits. */
    bankAccounts: {
      '20457743819027': { holder: 'Adaeze Okonkwo Studio Ltd', firstSeen: d(-1100), companies: ['11823456'] },
      '40116271553904': { holder: 'Northfield Precision Components Ltd', firstSeen: d(-2200), companies: ['10457721'] },
      '04007519374628': { holder: 'BL Trading Services', firstSeen: d(-2), companies: ['16034418', '14988102', '15520317'] },
      '60837122019844': { holder: 'Brightline Trade Supplies Ltd', firstSeen: d(-17), companies: ['16034418'] }
    },

    /** Payee accounts each seller has used over time. */
    sellerBankHistory: {
      '11823456': [{ account: '20457743819027', from: d(-1100), to: null }],
      '10457721': [{ account: '40116271553904', from: d(-2200), to: null }],
      '16034418': [
        { account: '60837122019844', from: d(-17), to: d(-2) },
        { account: '04007519374628', from: d(-2), to: null }
      ]
    },

    /** Mock buyer payment-history data. */
    paymentHistory: {
      '09876543': { invoices: 24, onTime: 22, late: 2, avgDaysLate: 4, maxDaysLate: 7, defaults: 0, disputes: 0, typicalTermDays: 30, monthlyVolume: 9500, months: 30 },
      '08812290': { invoices: 6, onTime: 4, late: 2, avgDaysLate: 12, maxDaysLate: 19, defaults: 0, disputes: 0, typicalTermDays: 30, monthlyVolume: 22000, months: 7 },
      '07345120': { invoices: 58, onTime: 56, late: 2, avgDaysLate: 3, maxDaysLate: 5, defaults: 0, disputes: 1, typicalTermDays: 60, monthlyVolume: 140000, months: 48 }
    },

    /** Demo invoice & financing ledger used for duplicate searches. */
    financingLedger: {
      recordsSearched: 1284,
      records: [
        { invoiceNumber: 'INV-2026-011', sellerReg: '11823456', buyerReg: '09876543', total: 3880, submittedAt: d(-75), status: 'Settled' },
        { invoiceNumber: 'NPC-23990', sellerReg: '10457721', buyerReg: '04411876', total: 12400, submittedAt: d(-140), status: 'Settled' },
        { invoiceNumber: 'INV-000186', sellerReg: '16034418', buyerReg: '07345120', total: 82080, submittedAt: d(-3), status: 'Submitted to another funder (demo consortium record)' }
      ]
    },

    /** Mock market price benchmarks matched by description keywords. */
    benchmarks: [
      { match: 'brand identity', label: 'Brand identity package', range: [1800, 4000], unit: 'package', sector: 'design' },
      { match: 'website design', label: 'Website design (per page)', range: [350, 600], unit: 'page', sector: 'design' },
      { match: 'support', label: 'Design support (hourly)', range: [60, 110], unit: 'hour', sector: 'design' },
      { match: 'bracket', label: 'Machined aluminium bracket', range: [14, 19], unit: 'unit', sector: 'metal-fabrication' },
      { match: 'mounting plate', label: 'Steel mounting plate', range: [12, 16], unit: 'unit', sector: 'metal-fabrication' },
      { match: 'tooling', label: 'Custom tooling setup', range: [1500, 3000], unit: 'job', sector: 'metal-fabrication' },
      { match: 'earbud', label: 'Wireless earbuds (wholesale)', range: [14, 22], unit: 'unit', sector: 'consumer-electronics' },
      { match: 'logistics', label: 'Express logistics & handling', range: [800, 2500], unit: 'job', sector: 'ancillary' }
    ]
  };

  /* ---------------------------------------------------------------- */
  /* Demo financing policy (NOT a real lending policy)                */
  /* ---------------------------------------------------------------- */

  const financingPolicy = [
    { min: 0, max: 20, band: 'Low', advanceRate: 0.8, action: 'Eligible', label: 'Eligible up to 80%' },
    { min: 21, max: 40, band: 'Moderate', advanceRate: 0.6, action: 'Eligible', label: 'Eligible up to 60%' },
    { min: 41, max: 60, band: 'Elevated', advanceRate: 0.4, action: 'Conditional', label: 'Up to 40% with review' },
    { min: 61, max: 75, band: 'High', advanceRate: 0, action: 'Manual review', label: 'Manual review' },
    { min: 76, max: 100, band: 'Severe', advanceRate: 0, action: 'Hold', label: 'Hold / decline' }
  ];

  window.ApexDemo = Object.freeze({
    today: d(0),
    scenarios,
    reference,
    financingPolicy,
    policyVersion: 'demo-policy-v2',
    modelVersion: 'mock-risk-model-0.4'
  });
})();
