/*
 * ApexVibe — frontend API layer (currently MOCKED)
 * ------------------------------------------------------------------
 * The UI only ever talks to `window.ApexApi`. Every method returns a
 * Promise and resolves with the same JSON shape the real backend is
 * expected to return, so switching to the real service is a matter of
 * setting CONFIG.mode = 'live' (and pointing CONFIG.baseUrl at it).
 *
 *   mode 'mock' → handlers below run in the browser against the
 *                 fictional reference data in demoData.js
 *   mode 'live' → request() calls fetch(`${baseUrl}${endpoint}`)
 *
 * IMPORTANT: nothing in mock mode checks a real registry, bank, credit
 * bureau or financing ledger. All results are labelled as simulated.
 * The scoring in calculateRisk() is a stand-in for the backend-owned
 * risk model; it exists only so the UI has realistic data to display.
 */
(function () {
  'use strict';

  const CONFIG = {
    mode: 'mock',             // 'mock' | 'live'
    baseUrl: '/api/v1',
    minLatency: 280,
    maxLatency: 900
  };

  /** Failure simulation switches (driven from the Demo settings dialog). */
  const SIM = {
    failExtraction: false,
    registryOutage: false,
    paymentHistoryOutage: false,
    slowNetwork: false
  };

  const DAY = 864e5;
  const REF = () => window.ApexDemo.reference;

  class ApiError extends Error {
    constructor(message, code, retryable) {
      super(message);
      this.name = 'ApiError';
      this.code = code;
      this.retryable = retryable !== false;
    }
  }

  /* ---------------------------------------------------------------- */
  /* Transport                                                         */
  /* ---------------------------------------------------------------- */

  const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));

  function latency() {
    const factor = SIM.slowNetwork ? 3 : 1;
    const ms = (CONFIG.minLatency + Math.random() * (CONFIG.maxLatency - CONFIG.minLatency)) * factor;
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Single choke point for every backend call.
   * In live mode this becomes a plain fetch(); the UI does not change.
   */
  async function request(endpoint, payload, mockHandler) {
    if (CONFIG.mode === 'live') {
      const res = await fetch(CONFIG.baseUrl + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new ApiError(`Request to ${endpoint} failed (${res.status})`, `HTTP_${res.status}`, res.status >= 500);
      return res.json();
    }
    await latency();
    return clone(mockHandler(clone(payload)));
  }

  /* ---------------------------------------------------------------- */
  /* Helpers used by the mock handlers                                 */
  /* ---------------------------------------------------------------- */

  const SUFFIX = /\b(ltd|limited|plc|llp|llc|inc|co|company)\b/g;
  function normName(s) {
    return String(s || '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9 ]/g, ' ').replace(SUFFIX, ' ').replace(/\s+/g, ' ').trim();
  }
  function normText(s) {
    return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }
  function digits(s) { return String(s || '').replace(/\D/g, ''); }
  function parseDate(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ''))) return null;
    const t = new Date(s + 'T12:00:00');
    return isNaN(t) ? null : t;
  }
  function daysSince(s) {
    const t = parseDate(s);
    return t ? Math.round((parseDate(window.ApexDemo.today) - t) / DAY) : null;
  }
  function termDays(terms) {
    const m = String(terms || '').match(/(\d{1,3})/);
    return m ? Number(m[1]) : null;
  }
  function money(n, cur) {
    try { return new Intl.NumberFormat('en-GB', { style: 'currency', currency: cur || 'GBP', maximumFractionDigits: n % 1 ? 2 : 0 }).format(n); }
    catch (e) { return `${cur || ''} ${Number(n).toLocaleString('en-GB')}`; }
  }
  function ageText(days) {
    if (days == null) return 'unknown';
    if (days < 60) return `${days} days`;
    if (days < 730) return `${Math.round(days / 30)} months`;
    return `${(days / 365).toFixed(1)} years`;
  }
  /** Shape of an invoice number: digits → 9, letters → A. */
  function numberShape(n) { return String(n || '').toUpperCase().replace(/[0-9]/g, '9').replace(/[A-Z]/g, 'A'); }
  function numberTail(n) { const m = String(n || '').match(/(\d+)\D*$/); return m ? Number(m[1]) : null; }

  let seq = 0;
  /** A single finding/signal. Every evidence item in the UI has this shape. */
  function finding(o) {
    seq += 1;
    return Object.assign({
      id: `${o.module || 'f'}-${o.code || seq}`,
      status: 'pass',            // pass | warning | fail | unavailable
      severity: 'none',          // none | low | medium | high | critical
      category: 'invoiceIntegrity',
      riskType: 'verification',  // fraud | credit | transaction | verification
      scoreImpact: 0,
      confidence: 0.9,
      title: '',
      observation: '',
      expected: '',
      difference: '',
      whyItMatters: '',
      whatToCheck: [],
      reviewTask: null,
      comparison: null,
      evidence: [],
      dataSource: '',
      fraudRelevant: false,
      simulated: true
    }, o);
  }

  const STATUS_RANK = { pass: 0, warning: 1, unavailable: 2, fail: 3 };
  function moduleResult(findings, summaryPass, extra) {
    let status = 'pass';
    findings.forEach((f) => { if (STATUS_RANK[f.status] > STATUS_RANK[status]) status = f.status; });
    const issues = findings.filter((f) => f.status !== 'pass');
    const scoreImpact = issues.reduce((s, f) => s + f.scoreImpact, 0);
    const confidence = findings.length ? findings.reduce((s, f) => s + f.confidence, 0) / findings.length : 0.9;
    const summary = issues.length
      ? issues.slice(0, 2).map((f) => f.title).join(' · ') + (issues.length > 2 ? ` · +${issues.length - 2} more` : '')
      : summaryPass;
    return Object.assign({ status, scoreImpact, confidence: Math.round(confidence * 100) / 100, summary, findings }, extra || {});
  }

  function unavailable(module, category, what, source) {
    return finding({
      module, code: 'unavailable', status: 'unavailable', severity: 'medium', category, riskType: 'verification',
      scoreImpact: 10, confidence: 1,
      title: `Unable to verify — ${what}`,
      observation: `${source} did not respond during this assessment.`,
      expected: 'A response from the reference source.',
      difference: 'No data was returned, so this check could not be completed.',
      whyItMatters: 'Missing information is not treated as safe. It increases verification uncertainty until the check can be completed.',
      whatToCheck: ['Re-run the assessment when the source is available.', 'Obtain the information directly from an independent source.'],
      reviewTask: `Complete the unavailable check: ${what}`,
      dataSource: source
    });
  }

  /* ---------------------------------------------------------------- */
  /* Mock handlers                                                     */
  /* ---------------------------------------------------------------- */

  function mockValidate({ invoice }) {
    const v = window.ApexValidation.run(invoice);
    const src = 'Frontend validation rules (client-side)';
    const map = {
      required: { fail: ['verification', 10, 'medium'], warning: ['verification', 3, 'low'] },
      arithmetic: { fail: ['fraud', 12, 'high'], warning: ['transaction', 5, 'low'] },
      dates: { fail: ['transaction', 8, 'medium'], warning: ['transaction', 4, 'low'] },
      currency: { fail: ['transaction', 6, 'medium'], warning: ['transaction', 3, 'low'] },
      entity: { fail: ['fraud', 8, 'medium'], warning: ['verification', 3, 'low'] }
    };
    const findings = v.checks.map((c) => {
      // Payee-name issues are scored by checkBankDetails, not here, to avoid double counting.
      const scored = c.issues.filter((i) => !i.scoredElsewhere);
      let status = c.status;
      if (c.id === 'entity' && !scored.length && status !== 'pass') status = 'pass';
      const m = (map[c.id] || {})[status];
      return finding({
        module: 'validateInvoice', code: c.id, category: 'invoiceIntegrity',
        status, severity: m ? m[2] : 'none', riskType: m ? m[0] : 'verification', scoreImpact: m ? m[1] : 0,
        fraudRelevant: c.id === 'arithmetic' && status === 'fail',
        confidence: 0.99,
        title: status === 'pass' ? `${c.label}: consistent` : `${c.label}: ${c.summary}`,
        observation: c.status === 'pass' ? c.summary : c.issues.map((i) => i.text).join(' '),
        expected: c.expected,
        difference: status === 'pass' ? (c.id === 'entity' && c.status !== 'pass' ? 'Payee-name difference is assessed under payment account checks.' : 'None found.') : scored.map((i) => i.text).join(' '),
        whyItMatters: c.why,
        whatToCheck: status === 'pass' ? [] : c.toCheck,
        reviewTask: status === 'pass' ? null : c.reviewTask,
        dataSource: src
      });
    });
    return moduleResult(findings, 'Required fields, arithmetic, dates, currency and entities consistent', { validation: v });
  }

  function mockVerifyBuyer({ buyer }) {
    const source = 'Demo company registry (mock)';
    if (SIM.registryOutage) return moduleResult([unavailable('verifyBuyer', 'buyer', 'buyer identity', source)], '', { source });
    const rec = REF().companies[String(buyer.registrationNumber || '').trim()];
    const f = [];
    if (!rec) {
      f.push(finding({
        module: 'verifyBuyer', code: 'nomatch', status: 'unavailable', severity: 'medium', category: 'buyer', riskType: 'verification', scoreImpact: 12, confidence: 0.9,
        title: 'Unable to verify buyer — no registry match',
        observation: `No demo registry record for registration number "${buyer.registrationNumber || '—'}".`,
        expected: 'An active registry record matching the buyer’s legal name.',
        difference: 'Buyer identity could not be matched.',
        whyItMatters: 'An unverified buyer means the obligor behind the receivable is unknown. This raises verification uncertainty, not necessarily fraud.',
        whatToCheck: ['Confirm the buyer’s legal name and registration number.', 'Check the number for typing errors against the original document.'],
        reviewTask: 'Confirm buyer legal entity and registration number',
        dataSource: source
      }));
      return moduleResult(f, '', { source });
    }
    const nameOk = normName(rec.name) === normName(buyer.name);
    const addrOk = normText(rec.address) === normText(buyer.address);
    f.push(finding({
      module: 'verifyBuyer', code: 'identity', category: 'buyer', riskType: nameOk ? 'verification' : 'fraud',
      status: nameOk ? 'pass' : 'warning', severity: nameOk ? 'none' : 'medium', scoreImpact: nameOk ? 0 : 10, confidence: 0.93,
      title: nameOk ? 'Simulated registry match — buyer' : 'Buyer name differs from registry record',
      observation: `Invoice names the buyer as “${buyer.name}”. Registry record ${buyer.registrationNumber}: “${rec.name}”, status ${rec.status}, incorporated ${ageText(daysSince(rec.incorporated))} ago.`,
      expected: 'Invoice buyer name matches the registered legal name.',
      difference: nameOk ? 'None.' : 'Name on invoice does not match the registered name for this number.',
      whyItMatters: 'The receivable is only as good as the buyer’s obligation to pay. A mismatched name may mean the wrong entity, a trading name, or an altered invoice.',
      whatToCheck: nameOk ? [] : ['Confirm the correct legal entity with the buyer.', 'Check whether a trading name is being used.'],
      reviewTask: nameOk ? null : 'Confirm buyer legal entity name',
      comparison: { leftLabel: 'Invoice claim', left: buyer.name, rightLabel: 'Demo registry', right: `${rec.name} · ${rec.status}` },
      dataSource: source
    }));
    f.push(finding({
      module: 'verifyBuyer', code: 'address', category: 'buyer', riskType: 'verification',
      status: addrOk ? 'pass' : 'warning', severity: addrOk ? 'none' : 'low', scoreImpact: addrOk ? 0 : 4, confidence: 0.86,
      title: addrOk ? 'Buyer address matches registered address' : 'Buyer address differs from registered address',
      observation: `Invoice: ${buyer.address || '—'}`,
      expected: `Registered: ${rec.address}`,
      difference: addrOk ? 'None.' : 'Address on invoice is not the registered address.',
      whyItMatters: 'Address differences are often benign (branch or billing address) but can indicate an altered document.',
      whatToCheck: addrOk ? [] : ['Confirm the billing address with the buyer through a known contact.'],
      reviewTask: addrOk ? null : 'Confirm buyer billing address',
      dataSource: source
    }));
    if (rec.status !== 'Active') {
      f.push(finding({ module: 'verifyBuyer', code: 'status', status: 'fail', severity: 'high', category: 'buyer', riskType: 'credit', scoreImpact: 20, confidence: 0.95,
        title: `Buyer registry status: ${rec.status}`, observation: `Registry status is ${rec.status}.`, expected: 'Active', difference: 'Buyer is not active.',
        whyItMatters: 'An inactive buyer may be unable to pay.', whatToCheck: ['Confirm buyer trading status.'], reviewTask: 'Confirm buyer trading status', dataSource: source }));
    }
    return moduleResult(f, 'Simulated registry match: buyer active, name and address consistent', { source, record: rec });
  }

  function mockVerifySeller({ seller, invoice }) {
    const source = 'Demo company registry (mock)';
    if (SIM.registryOutage) return moduleResult([unavailable('verifySeller', 'seller', 'seller identity and business activity', source)], '', { source });
    const ref = REF();
    const rec = ref.companies[String(seller.registrationNumber || '').trim()];
    const f = [];
    if (!rec) {
      f.push(finding({
        module: 'verifySeller', code: 'nomatch', status: 'unavailable', severity: 'medium', category: 'seller', riskType: 'verification', scoreImpact: 14, confidence: 0.9,
        title: 'Unable to verify seller — no registry match',
        observation: `No demo registry record for registration number "${seller.registrationNumber || '—'}".`,
        expected: 'An active registry record matching the seller’s legal name.', difference: 'Seller identity could not be matched.',
        whyItMatters: 'Without a matched seller, the party receiving funds is unconfirmed.',
        whatToCheck: ['Confirm the seller’s registration number from an independent source.'],
        reviewTask: 'Confirm seller legal entity and registration number', dataSource: source
      }));
      return moduleResult(f, '', { source });
    }
    const age = daysSince(rec.incorporated);
    const nameOk = normName(rec.name) === normName(seller.name);
    f.push(finding({
      module: 'verifySeller', code: 'identity', category: 'seller', riskType: nameOk ? 'verification' : 'fraud',
      status: nameOk ? 'pass' : 'warning', severity: nameOk ? 'none' : 'medium', scoreImpact: nameOk ? 0 : 10, confidence: 0.93,
      title: nameOk ? 'Simulated registry match — seller' : 'Seller name differs from registry record',
      observation: `Invoice seller “${seller.name}”. Registry record ${seller.registrationNumber}: “${rec.name}”, status ${rec.status}.`,
      expected: 'Seller name matches the registered legal name.',
      difference: nameOk ? 'None.' : 'Names do not match.',
      whyItMatters: 'Impersonating an established company is a common way to make a fabricated invoice look credible.',
      whatToCheck: nameOk ? [] : ['Confirm the seller entity using registry data you retrieve yourself.'],
      reviewTask: nameOk ? null : 'Confirm seller legal entity',
      comparison: { leftLabel: 'Invoice claim', left: seller.name, rightLabel: 'Demo registry', right: `${rec.name} · ${rec.status}` },
      dataSource: source
    }));

    // Company age
    const young = age != null && age < 90;
    f.push(finding({
      module: 'verifySeller', code: 'age', category: 'seller', riskType: 'fraud', fraudRelevant: true,
      status: young ? 'fail' : (age < 365 ? 'warning' : 'pass'), severity: young ? 'high' : (age < 365 ? 'low' : 'none'),
      scoreImpact: young ? 14 : (age < 365 ? 4 : 0), confidence: 0.97,
      title: young ? `Seller incorporated ${age} days ago` : `Seller trading for ${ageText(age)}`,
      observation: `Incorporation date ${rec.incorporated} (${ageText(age)} ago). Accounts filed: ${rec.accountsFiled ? 'yes' : 'none yet'}.`,
      expected: 'Financed sellers typically have at least 12 months of trading history.',
      difference: young ? `Company is only ${age} days old.` : 'None.',
      whyItMatters: 'Newly created companies have no track record to compare against. Recently incorporated entities are disproportionately used in invoice and payment fraud, although most new companies are legitimate.',
      whatToCheck: young ? ['Verify directors and beneficial owners.', 'Ask for evidence of trading activity (contracts, bank statements, prior invoices).', 'Confirm the seller exists at its registered address.'] : [],
      reviewTask: young ? 'Verify seller ownership and trading history' : null,
      evidence: [{ label: 'Incorporated', value: rec.incorporated }, { label: 'Directors', value: rec.directors.join(', ') }],
      dataSource: source
    }));

    // Registered address vs invoice address
    const addrOk = normText(rec.address) === normText(seller.address);
    f.push(finding({
      module: 'verifySeller', code: 'address', category: 'seller', riskType: 'fraud', fraudRelevant: !addrOk,
      status: addrOk ? 'pass' : 'warning', severity: addrOk ? 'none' : 'low', scoreImpact: addrOk ? 0 : 6, confidence: 0.84,
      title: addrOk ? 'Seller address matches registered address' : 'Seller address/contact details inconsistent with registry',
      observation: `Invoice address: ${seller.address || '—'}. Invoice phone: ${seller.phone || '—'}.`,
      expected: `Registered address: ${rec.address}. Registered phone: ${rec.phone}.`,
      difference: addrOk ? 'None.' : 'Invoice uses an address that is not on the registry record.',
      whyItMatters: 'Fraudulent invoices often carry contact details controlled by the fraudster so that verification calls reach them.',
      whatToCheck: addrOk ? [] : ['Contact the seller using details from the registry, not from the invoice.'],
      reviewTask: addrOk ? null : 'Contact seller via independently sourced details',
      comparison: addrOk ? null : { leftLabel: 'On invoice', left: seller.address, rightLabel: 'Registered', right: rec.address },
      dataSource: source
    }));

    // Business activity vs invoiced goods
    const rules = ref.benchmarks;
    const itemSectors = (invoice.items || []).map((it) => {
      const r = rules.find((b) => String(it.description || '').toLowerCase().includes(b.match));
      return r ? r.sector : null;
    }).filter((s) => s && s !== 'ancillary');
    const mismatch = itemSectors.some((s) => !rec.sectors.includes(s));
    f.push(finding({
      module: 'verifySeller', code: 'activity', category: 'seller', riskType: 'fraud', fraudRelevant: mismatch,
      status: mismatch ? 'warning' : 'pass', severity: mismatch ? 'medium' : 'none', scoreImpact: mismatch ? 10 : 0, confidence: 0.8,
      title: mismatch ? 'Seller activity inconsistent with invoiced goods' : 'Seller activity consistent with invoiced goods/services',
      observation: `Registered activity: ${rec.activity}. Invoiced: ${(invoice.items || []).map((i) => i.description).join('; ')}.`,
      expected: 'Invoiced goods or services fall within the seller’s registered business activity.',
      difference: mismatch ? 'Goods invoiced do not match the registered activity.' : 'None.',
      whyItMatters: 'A company invoicing for goods outside its line of business may be fabricating trade or acting as a pass-through.',
      whatToCheck: mismatch ? ['Ask how the seller sources these goods (supplier invoices, import documents).', 'Request proof of delivery.'] : [],
      reviewTask: mismatch ? 'Verify seller’s ability to supply the invoiced goods' : null,
      dataSource: source
    }));

    // Invoice size vs turnover
    if (rec.annualTurnover && invoice.total > rec.annualTurnover * 0.25) {
      f.push(finding({
        module: 'verifySeller', code: 'turnover', category: 'seller', riskType: 'transaction', status: 'warning', severity: 'low', scoreImpact: 4, confidence: 0.75,
        title: 'Invoice is large relative to seller turnover',
        observation: `Invoice ${money(invoice.total, invoice.currency)} vs declared turnover ${money(rec.annualTurnover)}.`,
        expected: 'Single invoices below 25% of annual turnover.', difference: 'Unusually large share of turnover.',
        whyItMatters: 'Concentration in one invoice increases exposure to a single transaction.',
        whatToCheck: ['Ask for the contract supporting this order.'], reviewTask: 'Obtain contract for this order', dataSource: source
      }));
    }
    if (!rec.accountsFiled) {
      f.push(finding({
        module: 'verifySeller', code: 'accounts', category: 'seller', riskType: 'verification', status: 'warning', severity: 'low', scoreImpact: 6, confidence: 0.9,
        title: 'No filed accounts available for seller',
        observation: 'The demo registry holds no filed accounts for this company.', expected: 'At least one set of filed accounts.',
        difference: 'Historical turnover cannot be checked.',
        whyItMatters: 'Without accounts, claimed trading volume cannot be cross-checked. This raises verification uncertainty.',
        whatToCheck: ['Request management accounts or bank statements.'], reviewTask: 'Request seller financial statements', dataSource: source
      }));
    }
    return moduleResult(f, `Simulated registry match: seller active, ${ageText(age)} trading history`, { source, record: rec });
  }

  function mockRelationship({ buyer, seller, invoice }) {
    const ref = REF();
    const source = 'Mock relationship & onboarding data';
    const sReg = String(seller.registrationNumber || '').trim();
    const bReg = String(buyer.registrationNumber || '').trim();
    const rel = ref.relationships[`${sReg}|${bReg}`];
    const sRec = ref.companies[sReg];
    const bRec = ref.companies[bReg];
    const f = [];

    if (rel && rel.invoiceCount > 0) {
      const inRange = rel.range && invoice.total >= rel.range[0] * 0.8 && invoice.total <= rel.range[1] * 1.2;
      f.push(finding({
        module: 'analyzeRelationship', code: 'history', category: 'relationship', riskType: 'transaction',
        status: inRange ? 'pass' : 'warning', severity: inRange ? 'none' : 'medium', scoreImpact: inRange ? 0 : 8, confidence: 0.9,
        title: inRange ? `Established relationship — ${ageText(daysSince(rel.since))}, ${rel.invoiceCount} prior invoices` : 'Invoice outside historical relationship range',
        observation: `Trading since ${rel.since}; ${rel.invoiceCount} previous invoices between ${money(rel.range[0])} and ${money(rel.range[1])}; ${rel.disputes} disputes.`,
        expected: 'Invoice within the historical range for this relationship.',
        difference: inRange ? 'None.' : `Current invoice ${money(invoice.total, invoice.currency)} is outside the usual range.`,
        whyItMatters: 'A long, consistent history is strong evidence that the trade is genuine.',
        whatToCheck: inRange ? [] : ['Ask the buyer to confirm this order.'],
        reviewTask: inRange ? null : 'Obtain buyer confirmation of the order',
        evidence: [{ label: 'Buyer share of seller revenue', value: rel.buyerShareOfSellerRevenue != null ? `${Math.round(rel.buyerShareOfSellerRevenue * 100)}%` : 'n/a' }],
        dataSource: source
      }));
    } else {
      const days = rel ? daysSince(rel.since) : null;
      f.push(finding({
        module: 'analyzeRelationship', code: 'new', category: 'relationship', riskType: 'transaction', fraudRelevant: true,
        status: 'warning', severity: 'medium', scoreImpact: 8, confidence: 0.92,
        title: rel ? `New relationship — first invoice (${days} days since first contact)` : 'First recorded transaction between buyer and seller',
        observation: rel ? `Relationship opened ${rel.since}; ${rel.purchaseOrders || 0} purchase order(s), no paid invoices yet.` : 'No prior invoices, purchase orders or payments between these parties in the demo data.',
        expected: 'Some trading history between the parties.',
        difference: 'No historical behaviour to compare against.',
        whyItMatters: 'First transactions cannot be checked against past behaviour, so documentary evidence carries more weight.',
        whatToCheck: ['Obtain the purchase order or contract.', 'Obtain buyer acknowledgement of the invoice.'],
        reviewTask: 'Obtain buyer acknowledgement of invoice',
        dataSource: source
      }));
    }

    // Shared metadata between buyer and seller
    const shared = [];
    if (bRec && seller.phone && normText(seller.phone) === normText(bRec.phone)) shared.push({ label: 'Shared phone number', value: `${seller.phone} (seller’s invoice phone = buyer’s registered phone)` });
    if (sRec && bRec && normText(sRec.phone) === normText(bRec.phone)) shared.push({ label: 'Shared registered phone', value: sRec.phone });
    if (seller.address && buyer.address && normText(seller.address) === normText(buyer.address)) shared.push({ label: 'Shared address', value: seller.address });
    if (sRec && bRec && normText(sRec.address) === normText(bRec.address)) shared.push({ label: 'Shared registered address', value: sRec.address });
    if (sRec && bRec) {
      const dirs = sRec.directors.filter((x) => bRec.directors.includes(x));
      if (dirs.length) shared.push({ label: 'Shared director', value: dirs.join(', ') });
    }
    const sDev = ref.onboarding[sReg]; const bDev = ref.onboarding[bReg];
    if (sDev && bDev && sDev.deviceId === bDev.deviceId) shared.push({ label: 'Shared onboarding device', value: `Device fingerprint ${sDev.deviceId} (mock)` });
    if (seller.email && buyer.email && seller.email.split('@')[1] && seller.email.split('@')[1] === buyer.email.split('@')[1]) shared.push({ label: 'Shared email domain', value: seller.email.split('@')[1] });

    f.push(finding({
      module: 'analyzeRelationship', code: 'shared', category: 'relationship', riskType: 'fraud', fraudRelevant: shared.length > 0,
      status: shared.length >= 2 ? 'fail' : (shared.length ? 'warning' : 'pass'),
      severity: shared.length >= 2 ? 'high' : (shared.length ? 'medium' : 'none'),
      scoreImpact: Math.min(22, shared.length * 8), confidence: 0.88,
      title: shared.length ? 'Buyer and seller share suspicious metadata' : 'No related-party indicators found',
      observation: shared.length ? shared.map((s) => s.label).join(', ') + '.' : 'No shared phone, address, director, device or email domain in the demo data.',
      expected: 'Independent buyer and seller with no shared identifiers.',
      difference: shared.length ? `${shared.length} shared identifier(s).` : 'None.',
      whyItMatters: 'Shared identifiers may indicate related-party financing, synthetic counterparties or collusion between buyer and seller.',
      whatToCheck: shared.length ? ['Corporate ownership records, directors and beneficial owners.', 'Registered addresses of both parties.', 'Relationship history.', 'Independent confirmation from the buyer.'] : [],
      reviewTask: shared.length ? 'Investigate related-party indicators' : null,
      evidence: shared,
      dataSource: source
    }));

    // Supporting documents on file
    const docs = (rel && rel.documents) || { purchaseOrder: false, deliveryEvidence: false };
    const missing = [!docs.purchaseOrder && 'purchase order', !docs.deliveryEvidence && 'delivery evidence'].filter(Boolean);
    f.push(finding({
      module: 'analyzeRelationship', code: 'docs', category: 'transaction', riskType: 'verification', fraudRelevant: missing.length === 2,
      status: missing.length ? 'warning' : 'pass', severity: missing.length === 2 ? 'medium' : (missing.length ? 'low' : 'none'),
      scoreImpact: missing.length === 2 ? 8 : (missing.length ? 3 : 0), confidence: 0.95,
      title: missing.length ? `Missing supporting documents: ${missing.join(' and ')}` : 'Purchase order and delivery evidence on file',
      observation: `Purchase order: ${docs.purchaseOrder ? 'on file' : 'not on file'}. Delivery evidence: ${docs.deliveryEvidence ? 'on file' : 'not on file'}.`,
      expected: 'Purchase order and proof of delivery or service completion.',
      difference: missing.length ? `No ${missing.join(' or ')} in the mock document store.` : 'None.',
      whyItMatters: 'Documents linking the invoice to a real order and delivery are the most direct evidence the trade happened.',
      whatToCheck: missing.map((m) => `Obtain ${m}.`),
      reviewTask: missing.includes('purchase order') ? 'Verify purchase order / contract' : (missing.length ? 'Verify delivery or service completion' : null),
      dataSource: 'Mock document store'
    }));
    if (missing.includes('purchase order') && missing.includes('delivery evidence')) {
      f[f.length - 1].whatToCheck.push('Verify delivery or service completion.');
    }
    return moduleResult(f, 'Relationship consistent with history; no related-party indicators', { source });
  }

  function mockBankDetails({ invoice }) {
    const ref = REF();
    const source = 'Mock payee-account history';
    const seller = invoice.seller || {};
    const bank = invoice.bankDetails || {};
    const sReg = String(seller.registrationNumber || '').trim();
    const key = digits(bank.sortCode) + digits(bank.accountNumber);
    const acct = ref.bankAccounts[key];
    const history = ref.sellerBankHistory[sReg] || [];
    const f = [];

    // Beneficiary name vs legal seller name
    const payee = bank.accountName || seller.bankAccountName;
    const nameOk = payee && normName(payee) === normName(seller.name);
    f.push(finding({
      module: 'checkBankDetails', code: 'payee', category: 'seller', riskType: 'fraud', fraudRelevant: !nameOk,
      status: nameOk ? 'pass' : 'fail', severity: nameOk ? 'none' : 'high', scoreImpact: nameOk ? 0 : 12, confidence: 0.9,
      title: nameOk ? 'Payee name matches seller legal name' : 'Payment beneficiary differs from legal seller name',
      observation: `Payment requested to account named “${payee || '—'}”.`,
      expected: `Account held in the seller’s legal name “${seller.name || '—'}”.`,
      difference: nameOk ? 'None.' : 'Beneficiary name is not the invoicing company.',
      whyItMatters: 'Payment to an account not held by the invoicing company means funds may not reach the real seller.',
      whatToCheck: nameOk ? [] : ['Confirm the beneficiary name with the seller through a previously verified contact.', 'Ask why payment is directed to a different entity.'],
      reviewTask: nameOk ? null : 'Independently confirm seller bank details',
      comparison: { leftLabel: 'Payee on invoice', left: payee || '—', rightLabel: 'Legal seller', right: seller.name || '—' },
      dataSource: source
    }));

    // Account history / recent change
    const current = history.find((h) => h.account === key);
    const changed = history.length > 1 && current && current.to == null && daysSince(current.from) <= 30;
    const unknown = !current && history.length > 0;
    let status = 'pass'; let sev = 'none'; let impact = 0; let title = 'Payment account matches seller’s historical account';
    if (changed) { status = 'fail'; sev = 'high'; impact = 15; title = `Seller bank account changed ${daysSince(current.from)} days ago`; }
    else if (unknown) { status = 'fail'; sev = 'high'; impact = 15; title = 'Payment account not seen on previous seller invoices'; }
    else if (!history.length) { status = 'unavailable'; sev = 'low'; impact = 5; title = 'Unable to verify — no payee-account history for seller'; }
    const prev = history.filter((h) => h.account !== key);
    f.push(finding({
      module: 'checkBankDetails', code: 'change', category: 'seller', riskType: status === 'unavailable' ? 'verification' : 'fraud', fraudRelevant: changed || unknown,
      status, severity: sev, scoreImpact: impact, confidence: 0.91, title,
      observation: changed || unknown
        ? `The invoice requests payment to ${bank.sortCode || '—'} / ••••${String(bank.accountNumber || '').slice(-4)}, which differs from the account used on the seller’s earlier invoices.`
        : (history.length ? `Account in use since ${current ? current.from : '—'} in mock history.` : 'No payee-account history held for this seller.'),
      expected: prev.length ? `Previously used: ${prev.map((h) => `••••${h.account.slice(-4)} (${h.from}${h.to ? ' → ' + h.to : ''})`).join(', ')}` : 'Same account as earlier invoices.',
      difference: changed || unknown ? 'Payment instructions changed shortly before this invoice.' : (history.length ? 'None.' : 'Cannot compare.'),
      whyItMatters: 'Fraudsters sometimes compromise legitimate supplier communication and replace payment instructions with their own account.',
      whatToCheck: changed || unknown ? [
        'Call the seller using a previously verified phone number.',
        'Confirm the beneficiary name.',
        'Confirm whether the account was officially changed.',
        'Compare against earlier invoices.',
        'Do not rely solely on contact information contained in the suspicious invoice.'
      ] : (history.length ? [] : ['Confirm payment details with the seller via an independent channel.']),
      reviewTask: changed || unknown || !history.length ? 'Independently confirm seller bank details' : null,
      dataSource: source
    }));

    if (bank.currency && invoice.currency && bank.currency.toUpperCase() !== invoice.currency.toUpperCase()) {
      f.push(finding({
        module: 'checkBankDetails', code: 'currency', category: 'seller', riskType: 'transaction', status: 'warning', severity: 'low', scoreImpact: 4, confidence: 0.95,
        title: 'Payment account currency differs from invoice currency',
        observation: `Account currency ${bank.currency}; invoice currency ${invoice.currency}.`, expected: 'Same currency.', difference: 'Currency conversion would be required.',
        whyItMatters: 'Unexpected currency changes can indicate altered payment instructions.', whatToCheck: ['Confirm the settlement currency with the seller.'],
        reviewTask: 'Confirm settlement currency', dataSource: source
      }));
    }
    return moduleResult(f, 'Payee name matches seller; account consistent with mock history', { source, account: acct || null });
  }

  function mockBenchmark({ invoice }) {
    const ref = REF();
    const source = 'Mock market benchmarks & seller invoice profile';
    const f = [];
    const sReg = String((invoice.seller || {}).registrationNumber || '').trim();
    const bReg = String((invoice.buyer || {}).registrationNumber || '').trim();
    const prof = ref.sellerProfiles[sReg];
    const cur = invoice.currency;

    // Amount vs seller's normal volume
    if (prof) {
      const [lo, hi] = prof.typicalRange;
      const ratio = invoice.total / hi;
      const sev = ratio > 5 ? 'high' : ratio > 1.5 ? 'medium' : ratio > 1.2 ? 'low' : 'none';
      const impact = { high: 14, medium: 10, low: 4, none: 0 }[sev];
      f.push(finding({
        module: 'benchmarkTransaction', code: 'amount', category: 'transaction', riskType: 'transaction', fraudRelevant: sev === 'high' || sev === 'medium',
        status: sev === 'none' ? 'pass' : (sev === 'high' ? 'fail' : 'warning'), severity: sev, scoreImpact: impact, confidence: prof.invoicesLast12m < 5 ? 0.78 : 0.9,
        title: sev === 'none' ? 'Invoice amount within seller’s normal range' : 'Invoice amount is abnormal for this seller',
        observation: `Current invoice ${money(invoice.total, cur)}.`,
        expected: `Seller’s typical invoice ${money(lo, cur)}–${money(hi, cur)} (${prof.invoicesLast12m} invoices in last 12 months).`,
        difference: sev === 'none' ? 'None.' : `${ratio.toFixed(1)}× the top of the seller’s usual range.`,
        whyItMatters: 'A transaction far outside historical behaviour may indicate invoice inflation, fabricated trade, or an unusual legitimate transaction requiring review.',
        whatToCheck: sev === 'none' ? [] : ['Purchase order', 'Contract', 'Delivery evidence', 'Previous invoices', 'Explanation for the increase', 'Corresponding buyer confirmation'],
        reviewTask: sev === 'none' ? null : 'Obtain explanation and evidence for the invoice size',
        comparison: { leftLabel: 'Current invoice', left: money(invoice.total, cur), rightLabel: 'Seller’s typical invoice', right: `${money(lo, cur)}–${money(hi, cur)}` },
        dataSource: 'Mock seller invoice history'
      }));
    } else {
      f.push(finding({
        module: 'benchmarkTransaction', code: 'amount', status: 'unavailable', severity: 'low', category: 'transaction', riskType: 'verification', scoreImpact: 6, confidence: 1,
        title: 'Unable to verify — no invoicing history for seller', observation: 'No historical invoices held for this seller.', expected: 'Historical invoice profile.',
        difference: 'Invoice size cannot be benchmarked.', whyItMatters: 'Treated as unverified, not as normal.', whatToCheck: ['Request previous invoices from the seller.'],
        reviewTask: 'Request seller’s previous invoices', dataSource: 'Mock seller invoice history'
      }));
    }

    // Unit price vs market benchmark
    let worst = null;
    const lines = (invoice.items || []).map((it) => {
      const b = ref.benchmarks.find((x) => String(it.description || '').toLowerCase().includes(x.match));
      if (!b) return { it, b: null, dev: null };
      const dev = it.unitPrice > b.range[1] ? (it.unitPrice - b.range[1]) / b.range[1] : it.unitPrice < b.range[0] ? (it.unitPrice - b.range[0]) / b.range[0] : 0;
      const row = { it, b, dev };
      if (!worst || Math.abs(dev) > Math.abs(worst.dev)) worst = row;
      return row;
    });
    if (worst) {
      const a = Math.abs(worst.dev);
      const sev = a > 0.5 ? 'high' : a > 0.15 ? 'low' : a > 0 ? 'low' : 'none';
      const impact = a > 0.5 ? 12 : a > 0.15 ? 5 : a > 0 ? 2 : 0;
      f.push(finding({
        module: 'benchmarkTransaction', code: 'price', category: 'transaction', riskType: 'transaction', fraudRelevant: a > 0.5,
        status: impact ? (a > 0.5 ? 'fail' : 'warning') : 'pass', severity: sev, scoreImpact: impact, confidence: 0.82,
        title: impact ? `Market price ${a > 0.5 ? 'substantially ' : 'slightly '}outside benchmark — ${worst.b.label}` : 'Unit prices within demo market benchmarks',
        observation: `${worst.it.description}: ${money(worst.it.unitPrice, cur)} per ${worst.b.unit}.`,
        expected: `Demo market benchmark ${money(worst.b.range[0], cur)}–${money(worst.b.range[1], cur)} per ${worst.b.unit}.`,
        difference: impact ? `${Math.round(worst.dev * 100)}% ${worst.dev > 0 ? 'above' : 'below'} the benchmark range.` : 'None.',
        whyItMatters: 'Prices far from market can indicate inflated invoices (to borrow more against them) or mis-described goods.',
        whatToCheck: impact ? ['Ask for the price agreement or quotation.', 'Confirm specification of the goods with the buyer.'] : [],
        reviewTask: impact ? 'Confirm pricing against contract or quotation' : null,
        evidence: lines.filter((l) => l.b).map((l) => ({ label: l.it.description, value: `${money(l.it.unitPrice, cur)} vs ${money(l.b.range[0], cur)}–${money(l.b.range[1], cur)}` })),
        dataSource: 'Mock market benchmarks'
      }));
    }

    // Payment term anomaly vs buyer norms
    const ph = ref.paymentHistory[bReg];
    const days = termDays(invoice.paymentTerms);
    if (ph && days != null) {
      const odd = days < ph.typicalTermDays * 0.34 || days > ph.typicalTermDays * 2.5;
      f.push(finding({
        module: 'benchmarkTransaction', code: 'terms', category: 'transaction', riskType: 'transaction', fraudRelevant: odd,
        status: odd ? 'warning' : 'pass', severity: odd ? 'medium' : 'none', scoreImpact: odd ? 6 : 0, confidence: 0.85,
        title: odd ? 'Unusual payment terms' : 'Payment terms consistent with buyer norms',
        observation: `Invoice terms: ${invoice.paymentTerms} (${days} days).`,
        expected: `Buyer usually pays on ~${ph.typicalTermDays}-day terms (mock data).`,
        difference: odd ? `${days} days vs typical ${ph.typicalTermDays}.` : 'None.',
        whyItMatters: 'Unusually short terms create urgency, a common pressure tactic in payment-redirection fraud.',
        whatToCheck: odd ? ['Confirm agreed terms with the buyer’s accounts payable team.'] : [],
        reviewTask: odd ? 'Confirm agreed payment terms with buyer' : null,
        dataSource: 'Mock payment-history data'
      }));
    }
    return moduleResult(f, 'Amount, unit prices and terms within demo reference ranges', { source });
  }

  function mockPaymentHistory({ buyer }) {
    const source = 'Mock payment-history data';
    if (SIM.paymentHistoryOutage) return moduleResult([Object.assign(unavailable('analyzePaymentHistory', 'buyer', 'buyer payment history', source), { riskType: 'verification' })], '', { source, data: null });
    const ph = REF().paymentHistory[String(buyer.registrationNumber || '').trim()];
    const f = [];
    if (!ph) {
      f.push(finding({
        module: 'analyzePaymentHistory', code: 'none', status: 'unavailable', severity: 'medium', category: 'buyer', riskType: 'verification', scoreImpact: 10, confidence: 1,
        title: 'Unable to verify — no payment history for buyer', observation: 'No payment records held for this buyer.', expected: 'Payment history across previous invoices.',
        difference: 'Payment behaviour unknown.', whyItMatters: 'Unknown payment behaviour is treated as uncertain, not as good.',
        whatToCheck: ['Obtain trade references or a credit report.'], reviewTask: 'Obtain buyer credit information', dataSource: source
      }));
      return moduleResult(f, '', { source, data: null });
    }
    const lateRate = ph.late / ph.invoices;
    const sev = ph.defaults > 0 ? 'high' : lateRate > 0.25 ? 'medium' : ph.late ? 'low' : 'none';
    const impact = ph.defaults > 0 ? 25 : lateRate > 0.25 ? 14 : ph.late ? (ph.avgDaysLate > 5 ? 5 : 3) : 0;
    f.push(finding({
      module: 'analyzePaymentHistory', code: 'behaviour', category: 'buyer', riskType: 'credit',
      status: sev === 'none' ? 'pass' : (sev === 'high' ? 'fail' : 'warning'), severity: sev, scoreImpact: impact, confidence: ph.invoices < 10 ? 0.7 : 0.9,
      title: sev === 'none' ? 'Buyer pays on time' : `${ph.late} late payment${ph.late === 1 ? '' : 's'} in ${ph.invoices} invoices${ph.defaults ? `, ${ph.defaults} default(s)` : ''}`,
      observation: `${ph.invoices} invoices over ${ph.months} months: ${ph.onTime} on time, ${ph.late} late (avg ${ph.avgDaysLate} days, max ${ph.maxDaysLate}), ${ph.defaults} defaults, ${ph.disputes} disputes.`,
      expected: 'On-time payment rate above 90%, no defaults.',
      difference: sev === 'none' ? 'None.' : `${Math.round((1 - lateRate) * 100)}% on time.`,
      whyItMatters: 'Late payments delay repayment of a financed invoice and may signal cash-flow strain. This is credit risk, not fraud risk.',
      whatToCheck: sev === 'none' ? [] : ['Check recent trend of payment delays.', 'Confirm buyer has approved the invoice for payment.'],
      reviewTask: sev === 'medium' || sev === 'high' ? 'Review buyer’s recent payment behaviour' : null,
      evidence: [{ label: 'On-time rate', value: `${Math.round((ph.onTime / ph.invoices) * 100)}%` }, { label: 'Typical terms', value: `${ph.typicalTermDays} days` }],
      dataSource: source
    }));
    if (ph.invoices < 10) {
      f.push(finding({
        module: 'analyzePaymentHistory', code: 'limited', category: 'buyer', riskType: 'verification', status: 'warning', severity: 'low', scoreImpact: 6, confidence: 0.95,
        title: `Limited transaction history (${ph.invoices} invoices)`, observation: `Only ${ph.invoices} invoices over ${ph.months} months.`,
        expected: 'At least 10 invoices for a reliable picture.', difference: 'Small sample — behaviour may not be representative.',
        whyItMatters: 'Small samples make payment-behaviour estimates less reliable.', whatToCheck: ['Obtain trade references or credit bureau data.'],
        reviewTask: 'Obtain additional buyer credit references', dataSource: source
      }));
    }
    return moduleResult(f, `Mock payment-history data: ${ph.onTime}/${ph.invoices} on time, ${ph.defaults} defaults`, { source, data: ph });
  }

  function mockDuplicates({ invoice }) {
    const ref = REF();
    const source = 'Demo duplicate search (mock invoice & financing ledger)';
    const sReg = String((invoice.seller || {}).registrationNumber || '').trim();
    const bReg = String((invoice.buyer || {}).registrationNumber || '').trim();
    const recs = ref.financingLedger.records;
    const f = [];
    const exact = recs.find((r) => r.sellerReg === sReg && normText(r.invoiceNumber) === normText(invoice.invoiceNumber));
    const near = recs.find((r) => r !== exact && r.sellerReg === sReg && r.buyerReg === bReg && Math.abs(r.total - invoice.total) / Math.max(1, invoice.total) < 0.02 && daysSince(r.submittedAt) <= 30);
    if (exact) {
      f.push(finding({
        module: 'checkDuplicateInvoice', code: 'exact', category: 'network', riskType: 'fraud', fraudRelevant: true, status: 'fail', severity: 'critical', scoreImpact: 25, confidence: 0.96,
        title: 'Same invoice number already in financing ledger',
        observation: `${exact.invoiceNumber} recorded ${exact.submittedAt}: ${exact.status}.`, expected: 'Each invoice financed once.',
        difference: 'Invoice appears to have been submitted before.', whyItMatters: 'Financing the same receivable twice is a classic form of invoice fraud.',
        whatToCheck: ['Confirm with the seller whether this invoice was previously financed or assigned.'], reviewTask: 'Confirm invoice has not been assigned elsewhere', dataSource: source
      }));
    }
    if (near) {
      f.push(finding({
        module: 'checkDuplicateInvoice', code: 'near', category: 'network', riskType: 'fraud', fraudRelevant: true, status: 'fail', severity: 'high', scoreImpact: 16, confidence: 0.86,
        title: 'Near-duplicate invoice submitted for financing elsewhere',
        observation: `${near.invoiceNumber} — same seller, same buyer, ${money(near.total, invoice.currency)} — submitted ${daysSince(near.submittedAt)} days ago (${near.status}).`,
        expected: 'No other invoice with the same parties and amount in the recent period.',
        difference: `Only the invoice number differs (${near.invoiceNumber} vs ${invoice.invoiceNumber}).`,
        whyItMatters: 'Re-numbering an existing invoice is a common way to obtain financing for the same receivable more than once.',
        whatToCheck: ['Ask the seller to explain both invoices.', 'Obtain buyer confirmation of which invoice is genuine and outstanding.'],
        reviewTask: 'Investigate near-duplicate invoice', comparison: { leftLabel: 'This invoice', left: `${invoice.invoiceNumber} · ${money(invoice.total, invoice.currency)}`, rightLabel: 'Ledger record', right: `${near.invoiceNumber} · ${money(near.total, invoice.currency)}` },
        dataSource: source
      }));
    }
    if (!exact && !near) {
      f.push(finding({
        module: 'checkDuplicateInvoice', code: 'clear', category: 'network', riskType: 'fraud', status: 'pass', confidence: 0.85,
        title: 'Demo duplicate search: no matching record',
        observation: `Searched ${ref.financingLedger.recordsSearched.toLocaleString('en-GB')} demo ledger records for this seller, buyer, number and amount.`,
        expected: 'No prior record for this invoice.', difference: 'None found in demo data.',
        whyItMatters: 'This only covers the demo ledger. It does not prove the invoice has not been financed elsewhere.',
        dataSource: source
      }));
    }

    // Invoice number sequence
    const prof = ref.sellerProfiles[sReg];
    if (prof && prof.recentNumbers.length) {
      const last = prof.recentNumbers[prof.recentNumbers.length - 1];
      const shapeOk = numberShape(last) === numberShape(invoice.invoiceNumber);
      const gap = numberTail(invoice.invoiceNumber) - numberTail(last);
      const ok = shapeOk && gap > 0 && gap <= 60;
      f.push(finding({
        module: 'checkDuplicateInvoice', code: 'sequence', category: 'invoiceIntegrity', riskType: 'fraud', fraudRelevant: !ok,
        status: ok ? 'pass' : 'warning', severity: ok ? 'none' : 'medium', scoreImpact: ok ? 0 : 6, confidence: 0.8,
        title: ok ? 'Invoice number follows seller’s sequence' : 'Unusual invoice number sequence',
        observation: `This invoice: ${invoice.invoiceNumber}.`, expected: `Seller’s recent invoices: ${prof.recentNumbers.join(', ')}.`,
        difference: ok ? 'None.' : (shapeOk ? `Sequence jump of ${gap}.` : 'Numbering format differs from the seller’s previous invoices.'),
        whyItMatters: 'Invoices generated outside the seller’s normal billing system may be fabricated or altered.',
        whatToCheck: ok ? [] : ['Ask the seller for their invoice register.', 'Compare with previous invoices from this seller.'],
        reviewTask: ok ? null : 'Compare against seller’s previous invoices', dataSource: 'Mock seller invoice history'
      }));
    }

    // Creation timing
    const age = daysSince(invoice.issueDate);
    if (age != null && age <= 2 && age >= 0) {
      f.push(finding({
        module: 'checkDuplicateInvoice', code: 'timing', category: 'invoiceIntegrity', riskType: 'fraud', fraudRelevant: true, status: 'warning', severity: 'low', scoreImpact: 5, confidence: 0.75,
        title: `Invoice created ${age === 0 ? 'today' : age + ' day' + (age > 1 ? 's' : '') + ' before'} this assessment request`,
        observation: `Issue date ${invoice.issueDate}; submitted ${window.ApexDemo.today}.`, expected: 'Invoices usually reach financing after delivery has been confirmed.',
        difference: 'Very short gap between issue and submission.', whyItMatters: 'Invoices submitted immediately after creation are less likely to have been acknowledged by the buyer.',
        whatToCheck: ['Confirm the goods or services have been delivered.'], reviewTask: 'Verify delivery or service completion', dataSource: 'Submission metadata (mock)'
      }));
    }
    return moduleResult(f, 'Demo duplicate search clear; numbering consistent', { source });
  }

  function mockAssessFraud({ invoice, findings }) {
    const ref = REF();
    const source = 'Mock fraud-network graph';
    const bank = invoice.bankDetails || {};
    const key = digits(bank.sortCode) + digits(bank.accountNumber);
    const acct = ref.bankAccounts[key];
    const out = [];
    const sReg = String((invoice.seller || {}).registrationNumber || '').trim();
    if (acct && acct.companies.length > 1) {
      const others = acct.companies.filter((c) => c !== sReg).map((c) => (ref.companies[c] || { name: c }).name);
      out.push(finding({
        module: 'detectFraudPatterns', code: 'sharedaccount', category: 'network', riskType: 'fraud', fraudRelevant: true, status: 'fail', severity: 'high', scoreImpact: 14, confidence: 0.87,
        title: `Beneficiary account linked to ${acct.companies.length} companies`,
        observation: `Account ••••${key.slice(-4)} appears on invoices from: ${others.join(', ')}.`,
        expected: 'A business account used by one company.', difference: `${others.length} other companies use the same beneficiary account.`,
        whyItMatters: 'Multiple companies paying into one account is a hallmark of networks of synthetic or front companies.',
        whatToCheck: ['Identify who controls the account.', 'Review other invoices paid into this account.'],
        reviewTask: 'Investigate linked entities sharing the beneficiary account',
        evidence: others.map((o) => ({ label: 'Linked entity', value: o })), dataSource: source
      }));
    } else {
      out.push(finding({
        module: 'detectFraudPatterns', code: 'network', category: 'network', riskType: 'fraud', status: 'pass', confidence: 0.8,
        title: 'No linked-entity network found in mock graph', observation: 'Beneficiary account and contact details not shared with other entities in the demo graph.',
        expected: 'No links.', difference: 'None.', whyItMatters: 'Absence in demo data does not rule out links elsewhere.', dataSource: source
      }));
    }

    // Correlated patterns: several related anomalies across different categories
    const all = findings.concat(out).filter((f) => f.status !== 'pass' && (f.riskType === 'fraud' || f.fraudRelevant));
    const cats = new Set(all.map((f) => f.category));
    const hasHigh = all.some((f) => f.severity === 'high' || f.severity === 'critical');
    const patterns = [];
    if (all.length >= 4 && cats.size >= 3 && hasHigh) {
      const ranked = all.slice().sort((a, b) => b.scoreImpact - a.scoreImpact).slice(0, 6);
      patterns.push({
        id: 'pattern-1',
        title: 'Correlated risk pattern detected',
        typology: 'New entity · oversized first invoice · changed payment instructions · related parties',
        signalIds: ranked.map((f) => f.id),
        signals: ranked.map((f) => f.title),
        categories: Array.from(cats),
        uplift: Math.min(18, 8 + (all.length - 4) * 2),
        confidence: 0.84,
        explanation: 'Each signal may be explainable individually, but their combination materially increases the likelihood that the transaction requires investigation.'
      });
    }
    const res = moduleResult(out, `No correlated pattern detected (${all.length} fraud-relevant signal${all.length === 1 ? '' : 's'})`, { source, patterns });
    if (patterns.length) { res.status = 'fail'; res.summary = `${patterns[0].title}: ${all.length} related signals across ${cats.size} categories`; }
    return res;
  }

  const CATEGORIES = [
    { id: 'invoiceIntegrity', label: 'Invoice Integrity' },
    { id: 'seller', label: 'Seller Risk' },
    { id: 'buyer', label: 'Buyer Risk' },
    { id: 'relationship', label: 'Buyer–Seller Relationship' },
    { id: 'transaction', label: 'Transaction Risk' },
    { id: 'network', label: 'Financing / Fraud Network' }
  ];
  const WEIGHTS = {
    financing: { fraud: 1, credit: 0.8, transaction: 0.7, verification: 0.6 },
    buyer: { fraud: 1, credit: 0.2, transaction: 0.7, verification: 0.6 },
    seller: { fraud: 0.4, credit: 1, transaction: 0.5, verification: 0.6 }
  };
  const sat = (x) => Math.round((100 * x) / (x + 38));
  const typeBand = (s) => (s >= 55 ? 'High' : s >= 25 ? 'Medium' : 'Low');
  function overallBand(s) {
    return window.ApexDemo.financingPolicy.find((p) => s >= p.min && s <= p.max).band;
  }

  function mockCalculateRisk({ perspective, findings, patterns }) {
    const sums = { fraud: 0, credit: 0, transaction: 0, verification: 0 };
    const issues = findings.filter((f) => f.status !== 'pass');
    issues.forEach((f) => { sums[f.riskType] = (sums[f.riskType] || 0) + f.scoreImpact; });
    const uplift = (patterns || []).reduce((s, p) => s + p.uplift, 0);
    sums.fraud += uplift;
    const byType = {};
    Object.keys(sums).forEach((k) => { const s = sat(sums[k]); byType[k] = { score: s, band: typeBand(s), signals: issues.filter((f) => f.riskType === k).length }; });
    const w = WEIGHTS[perspective] || WEIGHTS.financing;
    const raw = Object.keys(sums).reduce((s, k) => s + sums[k] * w[k], 0);
    const score = sat(raw);
    const categories = CATEGORIES.map((c) => {
      const fs = findings.filter((f) => f.category === c.id);
      const iss = fs.filter((f) => f.status !== 'pass');
      const pts = iss.reduce((s, f) => s + f.scoreImpact, 0) + (c.id === 'network' ? uplift : 0);
      const cs = sat(pts);
      const unk = iss.some((f) => f.status === 'unavailable');
      return {
        id: c.id, label: c.label, score: cs, points: pts, checks: fs.length, issues: iss.length,
        status: unk && cs < 25 ? 'unavailable' : cs >= 40 ? 'fail' : cs > 0 ? 'warning' : 'pass',
        top: iss.slice().sort((a, b) => b.scoreImpact - a.scoreImpact)[0] || null
      };
    });
    const drivers = issues.slice().sort((a, b) => b.scoreImpact * b.confidence - a.scoreImpact * a.confidence).map((f) => f.id);
    const unavailableCount = issues.filter((f) => f.status === 'unavailable').length;
    return {
      perspective,
      overall: { score, band: overallBand(score) },
      byType,
      categories,
      drivers,
      patterns: patterns || [],
      unavailableCount,
      partial: unavailableCount > 0,
      modelVersion: window.ApexDemo.modelVersion,
      simulated: true
    };
  }

  function mockRecommendation({ perspective, invoice, risk, findings, paymentHistory }) {
    const s = risk.overall.score;
    const byId = Object.fromEntries(findings.map((f) => [f.id, f]));
    const has = (id) => byId[id] && byId[id].status !== 'pass';
    const fraudHigh = risk.byType.fraud.band === 'High';
    const fraudMed = risk.byType.fraud.band === 'Medium';
    const cur = invoice.currency;

    if (perspective === 'financing') {
      const tier = window.ApexDemo.financingPolicy.find((p) => s >= p.min && s <= p.max);
      let rate = tier.advanceRate; let headline; let action;
      if (tier.action === 'Eligible') { headline = 'Eligible for financing'; action = `Finance up to ${Math.round(rate * 100)}%`; }
      else if (tier.action === 'Conditional') { headline = 'Conditional — review required'; action = `Up to ${Math.round(rate * 100)}% after review`; }
      else if (tier.action === 'Manual review') { headline = 'Manual review required'; action = 'Hold pending review'; }
      else { headline = 'Manual review required'; action = 'HOLD'; }
      if (fraudHigh && rate > 0) { rate = 0; headline = 'Manual review required'; action = 'HOLD'; }
      return {
        perspective, headline, action, tone: s <= 20 ? 'ok' : s <= 60 ? 'warn' : 'bad',
        sub: rate > 0 ? (tier.action === 'Eligible' ? 'Standard verification steps apply' : 'Complete the verification steps before funding') : 'High-risk indicators detected. Additional verification is recommended.',
        advanceRate: rate, advanceAmount: Math.round(invoice.total * rate * 100) / 100,
        policyTier: tier, policyNote: 'Demo policy — final credit policy will be provided by the financing institution.'
      };
    }

    if (perspective === 'buyer') {
      const bankIssue = has('checkBankDetails-change') || has('checkBankDetails-payee') || has('detectFraudPatterns-sharedaccount');
      const sellerId = byId['verifySeller-identity'];
      const sellerStatus = !sellerId ? 'Unable to verify' : sellerId.status === 'pass' ? (has('verifySeller-age') ? 'Simulated match — new company' : 'Simulated registry match') : 'Mismatch';
      const integrityIssues = findings.filter((f) => (f.category === 'invoiceIntegrity' || f.code === 'near' || f.code === 'exact') && f.status !== 'pass').length;
      const invoiceStatus = integrityIssues === 0 ? 'Consistent' : integrityIssues <= 1 && !fraudHigh ? 'Minor discrepancies' : 'High-risk indicators';
      const acctRisk = bankIssue ? 'High' : has('checkBankDetails-currency') ? 'Medium' : 'Low';
      const caution = s > 20 || fraudMed || fraudHigh;
      let action; let tone;
      if (bankIssue) { action = 'Do not pay yet — independently verify changed bank details.'; tone = 'bad'; }
      else if (caution) { action = 'Hold payment until the invoice is matched to a purchase order and delivery.'; tone = 'warn'; }
      else { action = 'Proceed with payment under standard controls.'; tone = 'ok'; }
      return {
        perspective, tone,
        headline: bankIssue ? 'Do not pay yet' : caution ? 'Verify before paying' : 'OK to pay',
        sub: action, action: bankIssue ? 'Do not pay yet' : caution ? 'Hold & verify' : 'Proceed',
        invoiceStatus, sellerStatus, paymentAccountRisk: acctRisk, paymentAction: action
      };
    }

    // seller perspective
    const ph = paymentHistory;
    const credit = risk.byType.credit;
    const band = credit.band;
    const reliability = ph ? Math.round((ph.onTime / ph.invoices) * 100) : null;
    const terms = band === 'Low' ? 'Net 30' : band === 'Medium' ? 'Net 14 or 30% upfront' : 'Prepayment or letter of credit';
    const limitBase = ph ? ph.monthlyVolume : invoice.total;
    const limit = band === 'Low' ? limitBase * 2 : band === 'Medium' ? limitBase * 0.75 : 0;
    const docs = ['Signed purchase order'];
    if (band !== 'Low' || !ph) docs.push('Credit references or bureau report');
    if (has('analyzeRelationship-new')) docs.push('Signed master supply agreement');
    if (fraudHigh || fraudMed) docs.push('Confirmation that your own invoice and bank details on this document are correct');
    return {
      perspective,
      tone: band === 'High' ? 'bad' : band === 'Medium' || fraudHigh || fraudMed ? 'warn' : 'ok',
      headline: `Buyer payment risk: ${band}`,
      sub: band === 'Low' ? 'Buyer shows generally good payment behaviour (mock data).' : band === 'Medium' ? 'Offer shorter terms or partial prepayment.' : 'Avoid open-account terms.',
      action: terms,
      buyerPaymentRisk: band,
      reliability: reliability == null ? 'Unable to verify' : `${reliability}% on time${ph && ph.late ? ` · late payments avg ${ph.avgDaysLate} days` : ''}`,
      suggestedTerms: terms,
      creditLimit: Math.round(limit / 500) * 500,
      creditLimitText: limit ? money(Math.round(limit / 500) * 500, cur) : 'Secured terms only',
      documentation: docs,
      fraudNote: fraudHigh ? 'Fraud indicators on this invoice relate mainly to seller-side details. If this is your invoice, confirm the payment details printed on it have not been altered.' : null
    };
  }

  /* ---------------------------------------------------------------- */
  /* Public API — the only surface the UI uses                          */
  /* ---------------------------------------------------------------- */

  const api = {
    /** POST /api/v1/documents/extract (multipart). Mock: returns the selected demo profile. */
    async extractInvoice(file, opts) {
      opts = opts || {};
      if (CONFIG.mode === 'live') {
        const body = new FormData();
        if (file) body.append('file', file);
        const res = await fetch(`${CONFIG.baseUrl}/documents/extract`, { method: 'POST', body });
        if (!res.ok) throw new ApiError(`Extraction failed (${res.status})`, `HTTP_${res.status}`);
        return res.json();
      }
      await latency(); await latency();
      if (SIM.failExtraction) throw new ApiError('Extraction service unavailable (simulated failure). Your file is still attached — try again.', 'EXTRACTION_UNAVAILABLE', true);
      const sc = window.ApexDemo.scenarios.find((x) => x.id === opts.profile) || window.ApexDemo.scenarios[0];
      return {
        invoice: clone(sc.invoice),
        fieldConfidence: clone(sc.fieldConfidence || {}),
        method: file ? 'simulated' : 'demo',
        profile: sc.id,
        notice: file
          ? `Document received. Backend extraction is not connected in this frontend demo. Using simulated extraction results (${sc.label} profile).`
          : `${sc.label} sample invoice loaded with pre-extracted demo data.`,
        extractedAt: new Date().toISOString()
      };
    },
    /** POST /api/v1/invoices/validate */
    validateInvoice(invoice) { return request('/invoices/validate', { invoice }, mockValidate); },
    /** POST /api/v1/verification/buyer */
    verifyBuyer(buyer) { return request('/verification/buyer', { buyer }, mockVerifyBuyer); },
    /** POST /api/v1/verification/seller */
    verifySeller(seller, invoice) { return request('/verification/seller', { seller, invoice }, mockVerifySeller); },
    /** POST /api/v1/relationships/analyze */
    analyzeRelationship(buyer, seller, invoice) { return request('/relationships/analyze', { buyer, seller, invoice }, mockRelationship); },
    /** POST /api/v1/payments/bank-details */
    checkBankDetails(invoice) { return request('/payments/bank-details', { invoice }, mockBankDetails); },
    /** POST /api/v1/transactions/benchmark */
    benchmarkTransaction(invoice) { return request('/transactions/benchmark', { invoice }, mockBenchmark); },
    /** POST /api/v1/buyers/payment-history */
    getPaymentHistory(buyer) { return request('/buyers/payment-history', { buyer }, mockPaymentHistory); },
    /** POST /api/v1/invoices/duplicates */
    detectDuplicates(invoice) { return request('/invoices/duplicates', { invoice }, mockDuplicates); },
    /** POST /api/v1/fraud/assess */
    assessFraud(invoice, findings) { return request('/fraud/assess', { invoice, findings }, mockAssessFraud); },
    /** POST /api/v1/risk/score — the real model is backend-owned. */
    calculateRisk(context) { return request('/risk/score', context, mockCalculateRisk); },
    /** POST /api/v1/risk/recommendation */
    generateRecommendation(context) { return request('/risk/recommendation', context, mockRecommendation); },

    configure(sim) { Object.assign(SIM, sim || {}); },
    get mode() { return CONFIG.mode; },
    CATEGORIES,
    ApiError
  };

  window.ApexApi = api;
})();
